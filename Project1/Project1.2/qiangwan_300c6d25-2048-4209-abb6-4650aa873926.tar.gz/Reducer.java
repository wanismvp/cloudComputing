import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


public class Reducer {

	public static void main(String[] args) {
		new Reducer().start();
	}
            
        // create a ordered map to store the day view , day is the key, day view is the value
	public LinkedHashMap<String, Integer> createDayView() {
		LinkedHashMap<String, Integer>dayView = new LinkedHashMap<String, Integer>();
		int start = 20151201;
		for (int i = start; i <= 20151231; i++) {
			String key = i + "";
			dayView.put(key, 0);
		}
		return dayView;
	}

	public void start() {
	//	File file = new File("a.txt");
		try{
	//		BufferedReader br = new BufferedReader(new FileReader(file));
			BufferedReader br = 
	                      new BufferedReader(new InputStreamReader(System.in));
			LinkedHashMap<String, Integer>dayView = createDayView();

			
	        int totalView = 0;
	        String title = null;
	        int limit = 100000;
	        String input = null;
			while((input=br.readLine())!=null){
			    try{
					input = input.trim() ;
	                String currentTitle = input.split("\t")[0];
	                String currentDate = input.split("\t")[1];
	                String currentView = input.split("\t")[2];
	                // if currenttitle is the same with title update the  day view
	                if(currentTitle.equals(title)) {
	                	totalView += Integer.parseInt(currentView);
	                	dayView.put(currentDate, dayView.get(currentDate) + Integer.parseInt(currentView));
	                }else {
				// if not equal print the previous one
	                	if (title!= null && totalView > limit) {
	                		String ret="";
	            
	                		for(Map.Entry<String, Integer>entry :dayView.entrySet()) {
	                			ret += entry.getKey();
	                			ret += ":";
	                			ret +=entry.getValue();
						ret += "\t";
	        
	                		}
	                		ret = String.valueOf(totalView)+ "\t" + title + "\t" + ret;
	                		System.out.println(ret.trim());
	                		
	                	}
	                	// update the  title update the monthly view , empty the map and put the current view to the map
				title = currentTitle;
	                	totalView = Integer.parseInt(currentView);
                		dayView = createDayView();
                		dayView.put(currentDate, Integer.parseInt(currentView));
	                }
	                	
	            }catch(NumberFormatException e){
	                continue;
	            }
			}
			//output the last one
			if (title!= null && totalView > limit) {
        		String ret="";
    
        		for(Map.Entry<String, Integer>entry :dayView.entrySet()) {
        			ret += entry.getKey();
        			ret += ":";
        			ret +=entry.getValue();
        			ret += "\t";
        		}
        		
        		ret = String.valueOf(totalView)+ "\t" + title + "\t" + ret;
        		System.out.println(ret.trim());
        		
        	}
		}catch(IOException io){
			io.printStackTrace();
		}
		
		

	}
}
