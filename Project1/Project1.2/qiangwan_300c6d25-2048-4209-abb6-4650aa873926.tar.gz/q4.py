def readfile():
    file = open('output', 'r')
    n = 0
    ret = ''
    for line in file:
	#get view of the first day 
        firstdayview = int(line.split()[2].split(':')[1])
	# get the total view
        monthview = int(line.split()[0])
	#if meet the first day requirements then get the most popular one
        if firstdayview == 0 :
            if monthview > n:
                ret = line
                n = monthview
    title = ret.split()[1]
    print title

if __name__ == "__main__":
    file = readfile()
   #s =  '100785	2001:_A_Space_Odyssey_(film)	20151201:2867	20151202:2923	20151203:2996	20151204:2742	20151205:2590	20151206:3008	20151207:3207	20151208:3080	20151209:2992	20151210:3036	20151211:3876	20151212:3082	20151213:3165	20151214:3765	20151215:3542	20151216:3387	20151217:7469	20151218:3249	20151219:2813	20151220:2871	20151221:3408	20151222:2862	20151223:2525	20151224:2364	20151225:1950	20151226:5970	20151227:3388	20151228:3211	20151229:2903	20151230:2900	20151231:2644'
   #view = int(s.split()[2].split(':')[1])
   #print view
