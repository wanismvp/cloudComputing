def readfile():
    file = open('output', 'r')
    ret = 1
    longest = 0
    for line in file:
        long = find(line.split()[2:])
        #print long
       # print longest
        #print long
	# if the current is even longger update and reset
        if long > longest :
            ret = 1
            longest = long
	# if equal, plus one
        elif long == longest:
            ret = ret + 1
    print ret


# find the longest number of strictly decreasing sequence
def find(line):
    ret = 0
    new_line = [int (i.split(':')[1]) for i in line]
    l = 0
    while l < len(new_line):
        temp = 1
        while l < len(new_line) - 1 and new_line[l] > new_line[l+1]:
            l = l +  1
            temp = temp + 1
        if temp > ret:
            ret = temp
        l = l + 1
    return ret

if __name__ == "__main__":
    file = readfile()
