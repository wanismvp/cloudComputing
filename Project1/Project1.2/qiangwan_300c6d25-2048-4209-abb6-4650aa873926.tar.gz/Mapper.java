import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;




public class Mapper {
	public static void main(String[] args) {
		new Mapper().start();
	}	

	public void start() {
		String filename = System.getenv("mapreduce_map_input_file");
		String date =  filename.split("-")[(filename.split("-").length)-2];
		//File file = new File("pagecounts-20151201-000000");
		try {
			//BufferedReader br = new BufferedReader(new FileReader(file));
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String line = null;
			while((line = br.readLine()) != null) {
				boolean isValidate;
				isValidate = check(line);
				if(isValidate == true) {
					print(line, date);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	//format the output  hourView is the key
	public void print(String line, String date) {		
		String hourViews = line.split("\\s+")[2];
		String articleName = line.split("\\s+")[1];
		System.out.println(articleName + "\t" +date+ "\t" + hourViews);
	}
	
	public boolean check(String line) {
		if(filter0(line) && filter1(line) && filter2(line) && filter3(line) && filter4(line) && filter5(line)) {
			return true;
		}else{
			return false;
		}
		
	}
	
	public boolean filter0(String line) {
		int len = line.split("\\s+").length;
		if(len != 4) {
			return false;
		}
		return true;
	}
	
	public boolean filter1(String line) {
		if(line.split("\\s+")[0].equals("en") ) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public boolean filter2(String line) {
		String [] excludetopic = {"Media:", "Special:", "Talk:", "User:", "User_talk:", "Project:", "Project_talk:", "File:", "File_talk:", "MediaWiki:", "MediaWiki_talk:", "Template:", "Template_talk:", "Help:", "Help_talk:", "Category:", "Category_talk:", "Portal:", "Wikipedia:", "Wikipedia_talk:"};
		String title = line.split("\\s+")[1];
		for(String s : excludetopic) {
			if(title.startsWith(s)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean filter3(String line) {
		String title = line.split("\\s+")[1];
		char firstLetter = title.charAt(0);
		if(Character.isLowerCase(firstLetter)) {
			return false; 
		}else {
			return true;
		}
	}
	
	public boolean filter4(String line) {
		String [] extensionsexclude = {".jpg", ".gif", ".png", ".JPG", ".GIF", ".PNG", ".txt", ".ico"};
		String title = line.split("\\s+")[1];
		for(String s : extensionsexclude) {
			if(title.endsWith(s)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean filter5(String line) {
		String [] boilerplateexclude = {"404_error/","Main_Page", "Hypertext_Transfer_Protocol", "Search"};
		String title = line.split("\\s+")[1];
		for(String s : boilerplateexclude) {
			if(title.equals(s)) {
				return false;
			}
		}
		return true;		
	}
}
