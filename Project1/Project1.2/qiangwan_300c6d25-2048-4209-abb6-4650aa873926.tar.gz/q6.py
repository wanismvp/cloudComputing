import sys
def readfile():
    file = open('output', 'r')
    #titles = ['Jurassic_Park_(film)','The_Hunger_Games_(film)','Fifty_Shades_of_Grey_(film)','The_Martian_(film)','Interstellar_(film)']
    titles = []
    #get the input
    for input in sys.stdin:
        titles.append(input.strip())

    #list to store the input info  key is title value is the max of the day view
    ret = []
    for line in file:
        title = line.split()[1]
        if title in titles:
	    #get the max of these days
            info = max([int (i.split(':')[1]) for i in line.split()[2:]])
            ret.append((title, info))
    # sort the dict by the maximum singleday page views
    ret = sorted(ret, key = lambda x :x[1], reverse=True)
    str = ""
    #format the output
    str = ",".join([ x[0] for x in ret])

    print str



if __name__ == '__main__':
    #s ='100785	2001:_A_Space_Odyssey_(film)	20151201:2867	20151202:2923	20151203:2996	20151204:2742	20151205:2590	20151206:3008	20151207:3207	20151208:3080	20151209:2992	20151210:3036	20151211:3876	20151212:3082	20151213:3165	20151214:3765	20151215:3542	20151216:3387	20151217:7469	20151218:3249	20151219:2813	20151220:2871	20151221:3408	20151222:2862	20151223:2525	20151224:2364	20151225:1950	20151226:5970	20151227:3388	20151228:3211	20151229:2903	20151230:2900	20151231:2644'
    #s = s.split()
    #print s
    #print s
   readfile()
