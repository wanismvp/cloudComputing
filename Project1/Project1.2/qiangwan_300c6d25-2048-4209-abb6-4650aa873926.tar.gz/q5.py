import sys
def readfile():
    #get the input
    file = open('q5', 'r')
    twitter = file.readline().split('\n')[0]
    apple = file.readline().split('\n')[0]
   
    ret = 0
    first = ''
    second = ''
    for line in sys.stdin:
        title = line.split()[1]
	#get the specific  line 
        if title == twitter:
            first = line
        elif title == apple:
            second = line
    #get the the page view
    firstInfo = first.split()[2:]
    secondInfo = second.split()[2:]
    # count 
    for i in range(len(firstInfo)):
        num1 = firstInfo[i].split(':')[1]
        num2 = secondInfo[i].split(':')[1]
        if int(num1) > int(num2):
            ret = ret + 1

    print ret


if __name__ == "__main__":
    file = readfile()
