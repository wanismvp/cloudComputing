import  re
def readfile():
    file = open('output', 'r')
    # list sort the film and tv
    film = []
    tv = []
    for line in file:
        # match using regex
        article = line.split()[1]
        if re.match(r'(.+)_(\((\d{4}_)?film)\)', article):
            film.append(article)
        if re.match(r'(.+)_(\((\d{4}_)?TV_series\))',article):
            tv.append(article)

    new_film = [i.split('(')[0] for i in film]
    new_tv = [i.split('(')[0] for i in tv]
    # count match
    count = 0
    for i in new_film:
        for j in  new_tv:
            if i==j:
                count = count + 1
    print count


if __name__ == "__main__":
    readfile()
