def readfile():
#open the file
    file = open('output', 'r')
    n = 0
    ret = ''
    for line in file:
	#get the numbers of view on 18#
        view = int(line.split()[19].split(':')[1])
	# get the maximum
        if view > n :
            n = view
            ret = line
    #format the out put
    title = ret.split()[1]
    dailyview = ret.split()[19].split(':')[1]
    print title + '\t' + dailyview

if __name__ == "__main__":
    file = readfile()
