# read the file
def readfile():
    file = open('pagecounts-20151201-000000','r')
    return file

#prcess the file
def process(file):
    result = []
    for line in file:
        isvalidate = check(line)
        if isvalidate :
            result.append(line)
    # sort by the request
    result = sorted(result, key=lambda str: int(str.split()[2]), reverse=True)
    for line in result:
        print line

#filter the data according to the rules
def check(line):
    if filter0(line) and filter1(line) and filter2(line) and filter3(line) and filter4(line) and filter5(line) :
        return True
    else:
        return False

#filter the data whose length  is not equal to 4
def filter0(line):
    number = len(line.split());
    if number != 4 :
        return False
    return True
#filter the data which is not english
def filter1(line):
    if line.split()[0] !='en':
        return False
    return True

#filter the data with the following topic
def filter2(line):
    excludetopic = ['Media:', 'Special:', 'Talk:', 'User:', 'User_talk:', 'Project:', 'Project_talk:', 'File:', 'File_talk:', 'MediaWiki:', 'MediaWiki_talk:', 'Template:', 'Template_talk:', 'Help:', 'Help_talk:', 'Category:', 'Category_talk:', 'Portal:', 'Wikipedia:', 'Wikipedia_talk:']
    title = line.split()[1]
    for each in excludetopic :
        if title.startswith(each):
            return False
    return True
#filter the data the first letter of the titile is not upper case
def filter3(line):
    title = line.split()[1]
    firstletter = title[0]
    if firstletter.islower():
        return False
    return True
#filter the data with the following extension
def filter4(line):
    extensionsexclude = ['.jpg', '.gif', '.png', '.JPG', '.GIF', '.PNG', '.txt', '.ico']
    title = line.split()[1]
    for each in extensionsexclude:
        if title.endswith(each):
            return False
    return True

#filter the data with the following titles
def filter5(line):
    boilerplateexclude = ['404_error/','Main_Page', 'Hypertext_Transfer_Protocol', 'Search']
    title = line.split()[1]
    for each in boilerplateexclude:
        if title == each:
            return False
    return True

#main
if __name__ == "__main__" :
    file = readfile()
    process(file)
