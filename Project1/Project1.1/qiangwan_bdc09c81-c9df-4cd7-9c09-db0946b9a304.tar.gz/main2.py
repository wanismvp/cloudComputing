# total number of requests without filtering
def readfile():
    file = open('pagecounts-20151201-000000','r')
    return file

def process(file):
    count = 0
    for line in file:
        count = count + int(line.split()[-2])
    print count


if __name__ == "__main__" :
    file = readfile()
    process(file)