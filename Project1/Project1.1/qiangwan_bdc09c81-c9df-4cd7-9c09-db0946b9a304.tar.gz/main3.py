#lines after merge
def readfile():
    file = open('pagecounts-20151201-000000','r')
    return file

def process(file):
    count = 0
    for line in file:
        isvalidate = check(line)
        if isvalidate :
            count += 1
    print(count)
def check(line):
    if filter0(line) and filter1(line) and filter2(line) and filter3(line) and filter4(line) and filter5(line) :
        return True
    else:
        return False

def filter0(line):
    number = len(line.split());
    if number != 4 :
        return False
    return True

def filter1(line):
    if line.split()[0] !='en':
        return False
    return True

def filter2(line):
    excludetopic = ['Media:', 'Special:', 'Talk:', 'User:', 'User_talk:', 'Project:', 'Project_talk:', 'File:', 'File_talk:', 'MediaWiki:', 'MediaWiki_talk:', 'Template:', 'Template_talk:', 'Help:', 'Help_talk:', 'Category:', 'Category_talk:', 'Portal:', 'Wikipedia:', 'Wikipedia_talk:']
    title = line.split()[1]
    for each in excludetopic :
        if title.startswith(each):
            return False
    return True

def filter3(line):
    title = line.split()[1]
    firstletter = title[0]
    if firstletter.islower():
        return False
    return True

def filter4(line):
    extensionsexclude = ['.jpg', '.gif', '.png', '.JPG', '.GIF', '.PNG', '.txt', '.ico']
    title = line.split()[1]
    for each in extensionsexclude:
        if title.endswith(each):
            return False
    return True

def filter5(line):
    boilerplateexclude = ['404_error/','Main_Page', 'Hypertext_Transfer_Protocol', 'Search']
    title = line.split()[1]
    for each in boilerplateexclude:
        if title == each:
            return False
    return True

if __name__ == "__main__" :
    file = readfile()
    process(file)