import java.io.IOException;




import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class NGram {

  public static class Map
       extends Mapper<Object, Text, Text, IntWritable>{

    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();

    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
    	
       String curr = value.toString();
       String filteredData = filter(curr);
      
       String []words = filteredData.split("\\s+");
       for (int i = 0; i < words.length; i++) {
   			word.set(words[i]);
   			context.write(word, one);
   			
   			if(i + 1 < words.length) {
   				word.set(words[i] + " " + words[i+1]);
   	   			context.write(word, one);
   			}
   			
   			if (i + 2 < words.length) {
   				word.set(words[i] + " " + words[i+1] + " " + words[i+2]);
   				context.write(word, one);
   			}
   			
   			if (i + 3 < words.length) {
   				word.set(words[i] + " " + words[i+1] + " " + words[i+2] + " " + words[i+3]);
   	   			context.write(word, one);
   			}
   			
   			if (i + 4 < words.length) {
   				word.set(words[i] + " " + words[i+1] + " " + words[i+2]+ " " + words[i+3]+ " " + words[i+4]);
   	   			context.write(word, one);
   			}
       }
   		
   	}
       
	private  String filter(String input) {
		String ret = input.toLowerCase();
		ret = ret.replaceAll("<(\\/)?ref.*?>", " ")
				.replaceAll("(https?|ftp):\\/\\/[^\\s/$.?#][^\\s]*", " ")
				.replaceAll("'{2,}", " ");

		ret = ret.replaceAll("[^'a-z]", " ");
		
		String words [] = ret.split("\\s+");
		StringBuilder sb = new StringBuilder();
		for (String word : words) {
			String newWord = get(word);
			if(newWord.length() != 0) {
				sb.append(newWord + " ");
			}
		}
		return sb.toString().trim();
	}


	private String get(String word) {
		int l = 0;
		int r = word.length() - 1;
		while(l < word.length() && word.charAt(l) == '\'') {
			l ++;
		}
		
		while (r > 0 && word.charAt(r) == '\'') {
			r --;
		}
		
		if(l<=r) {
			return word.substring(l, r+1).trim();
		}else {
			return "";
		}
	}
    
  }

  public static class Reduce
       extends Reducer<Text,IntWritable,Text,IntWritable> {
    private IntWritable result = new IntWritable();

    public void reduce(Text key, Iterable<IntWritable> values,
                       Context context
                       ) throws IOException, InterruptedException {
      int sum = 0;
      for (IntWritable val : values) {
        sum += val.get();
      }
      result.set(sum);
      context.write(key, result);
    }
  }

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "n gram");
    job.setJarByClass(NGram.class);
    job.setMapperClass(Map.class);
    job.setCombinerClass(Reduce.class);
    job.setReducerClass(Reduce.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}
