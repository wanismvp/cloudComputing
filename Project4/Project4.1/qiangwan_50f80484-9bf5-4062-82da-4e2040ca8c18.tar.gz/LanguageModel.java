import java.io.IOException;
import java.util.Comparator;
import java.util.PriorityQueue;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableMapReduceUtil;
import org.apache.hadoop.hbase.mapreduce.TableReducer;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class LanguageModel {
	private static int t = 2;
	private static int n = 5;

  public static class Map
       extends Mapper<Object, Text, Text, Text>{
	  
    @Override
	protected void setup(Mapper<Object, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
    	Configuration configuration = context.getConfiguration();
    	t = configuration.getInt("t", t);
    	n = configuration.getInt("n", n);
    }
    
	public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
    	
       String curr = value.toString().trim();
       if (curr == null || curr.length() == 0) {
    	   return;
       }
       String[] keyValue = curr.split("\\t");
       if (keyValue.length != 2) {
    	   return;
       }
       String words = keyValue[0];
       int count = Integer.parseInt(keyValue[1]);
       
       if (count <= t || words.split("\\s+").length <= 1) {
    	   return;
       }

       StringBuilder phrase = new StringBuilder();
       String []temp =  words.split("\\s+");
       for (int i = 0; i <temp.length - 1; i++) {
    	   phrase.append(temp[i] + " ");
       }
       
       String word = temp[temp.length - 1];
     
       context.write(new Text(phrase.toString().trim()), new Text(word + " " + count));
    }
   		
  }
       
  public static class Reduce
       extends TableReducer<Text, Text, ImmutableBytesWritable> {
	  final static byte[] columnFamily = "data".getBytes();
	  final static Comparator<WordCount>countComparator = new Comparator<WordCount>() {
		  @Override
		  public int compare(WordCount wc1, WordCount wc2) {
			  if (wc1.count == wc2.count) {
				  return wc2.getWord().compareTo(wc1.getWord());
			  }
			  return wc1.count - wc2.count;  
		  }
		  
	  };
	  
	  public class WordCount {
		  private String word;
		  private int count;
		
		public String getWord() {
			return word;
		}
		public void setWord(String word) {
			this.word = word;
		}
		public int getCount() {
			return count;
		}
		public void setCount(int count) {
			this.count = count;
		}
	  }
	  
    public void reduce(Text key, Iterable<Text> values,
                       Context context
                       ) throws IOException, InterruptedException {
    	
      int sum = 0;
      
      PriorityQueue<WordCount>queue = new PriorityQueue<WordCount>(5, countComparator);
      	
      for (Text val : values) {
    	  String curr = val.toString();
    	  
    	  String word = curr.split(" ")[0];
    	  int count = Integer.parseInt(curr.split(" ")[1]);
    	  
    	  WordCount wc = new WordCount();
    	  
    	  wc.setWord(word);
    	  wc.setCount(count);
    	  
    	  queue.add(wc);
    	  while (queue.size() > 5) {
    		  queue.poll();
    	  }
    
    	  sum += count;
      }
      int size = Math.min(5, queue.size());
      Put put = new Put(Bytes.toBytes(key.toString()));
      for (int i = 0; i < size ; i ++) {
    	  WordCount wc = queue.poll();
    	  double pro = wc.getCount() * 1.0  /  sum;
    	  put.add(columnFamily, wc.getWord().getBytes(), String.valueOf(pro).getBytes());
      }
      
      context.write(null, put);
    }
  }
  
 



  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    
    Options options = new Options();
    options.addOption("t", true, "hihi");
    options.addOption("n", true, "haha");
    options.addOption("input", true, "haha");
    
    GenericOptionsParser optionParser = new GenericOptionsParser(conf, options, args);
    CommandLine cmd = optionParser.getCommandLine();
    conf.setInt("t", Integer.valueOf(cmd.getOptionValue("t")));
    conf.setInt("n", Integer.valueOf(cmd.getOptionValue("n")));
    
    Job job = Job.getInstance(conf, "language");
    job.setJarByClass(LanguageModel.class);
    job.setMapperClass(Map.class);
    
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);
    FileInputFormat.addInputPaths(job, cmd.getOptionValue("input"));
   
    TableMapReduceUtil.initTableReducerJob("wp", Reduce.class, job);
    System.exit(job.waitForCompletion(true) ? 0 : 1);
    
  }
}
