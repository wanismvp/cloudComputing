import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.TimeZone;
import java.util.Iterator;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.sql.Timestamp;

import org.vertx.java.core.Handler;
import org.vertx.java.core.MultiMap;
import org.vertx.java.core.http.HttpServer;
import org.vertx.java.core.http.HttpServerRequest;
import org.vertx.java.core.http.RouteMatcher;
import org.vertx.java.platform.Verticle;

public class Coordinator extends Verticle {

	//Default mode: sharding. Possible string values are "replication" and "sharding"
	private static String storageType = "replication";
	/**
	 * TODO: Set the values of the following variables to the DNS names of your
	 * three dataCenter instances
	 */
	private static final String dataCenter1 = "ec2-54-173-201-116.compute-1.amazonaws.com";
	private static final String dataCenter2 = "ec2-54-174-35-239.compute-1.amazonaws.com";
	private static final String dataCenter3 = "ec2-54-173-255-78.compute-1.amazonaws.com";
	
	//this is the hashfunction 
	public String hashFunction(String key) {
		if(key.equals("A")) {
			return dataCenter1;
		}else if(key.equals("B")) {
			return dataCenter2;
		}else if(key.equals("C")) {
			return dataCenter3;
		}else{
			int code = 0;
			for(int i=0; i<key.length(); i++) {
				code += key.charAt(i);
			}

			if(code%3 == 0) {
				return dataCenter1;
			}else if(code%3 == 1) {
				return dataCenter2;
			}else {
				return dataCenter3;
			}
		}
	}
	
	@Override
	public void start() {						
		//DO NOT MODIFY THIS
		KeyValueLib.dataCenters.put(dataCenter1, 1);
		KeyValueLib.dataCenters.put(dataCenter2, 2);
		KeyValueLib.dataCenters.put(dataCenter3, 3);
		final RouteMatcher routeMatcher = new RouteMatcher();
		final HttpServer server = vertx.createHttpServer();
		server.setAcceptBacklog(32767);
		server.setUsePooledBuffers(true);
		server.setReceiveBufferSize(4 * 1024);
		
		// this is the comparartor for the priority queue
		final Comparator<String>timestampComparator = new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		};
		
		//for each key, I need a thread-safe priority blocking queue
		HashMap<String, PriorityBlockingQueue<String>>hashMap = new HashMap<String, PriorityBlockingQueue<String>>();
		//for each key, I also need a lock
		HashMap<String, Object>locks = new HashMap<String, Object>();

		routeMatcher.get("/put", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				final String key = map.get("key");
				final String value = map.get("value");
				//You may use the following timestamp for ordering requests
                                final String timestamp = new Timestamp(System.currentTimeMillis() 
                                                                + TimeZone.getTimeZone("EST").getRawOffset()).toString();

                // if i dont have the key in hashmap , create one lock and a queue for it and then put the task in the queue
                if(!hashMap.containsKey(key)) {
                	PriorityBlockingQueue<String>lbq = new PriorityBlockingQueue<String>(10,timestampComparator);
                	Object lock = new Object();
                	lbq.put(timestamp);
                	hashMap.put(key, lbq);
                	locks.put(key,lock);
                }else {	
                // if i have the queue for the queue, just put the task
                	PriorityBlockingQueue<String>lbq = hashMap.get(key);
                	lbq.put(timestamp);
                }
                                
                // one I get a request, I create a new thread to handle it, maybe need to queue up
				Thread t = new Thread(new Runnable() {
					public void run() {
						//TODO: Write code for PUT operation here. 
						//Each PUT operation is handled in a different thread.
						//Highly recommended that you make use of helper functions.

						//get the the queue for the key
					    PriorityBlockingQueue<String>currpbq = hashMap.get(key);  
						//get the task with smallest timestamp, and the whether it matches the thread created for it
						// at the first beginning, if not I need to wait then need to be notified to keep moving

					    while(!currpbq.peek().equals(timestamp)) {
					    	synchronized (locks.get(key)) {
				    			try {
									locks.get(key).wait();
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
				    		}
					    
					    }
					    
					    //for replication when put need to put 3 times.
					    if(storageType.equals("replication")) {
					    	try {
								KeyValueLib.PUT(dataCenter1, key, value);
								KeyValueLib.PUT(dataCenter2, key, value);
								KeyValueLib.PUT(dataCenter3, key, value);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						// for sharding put ones with the location of the hash of the key
					    }else {
					    	try {
								KeyValueLib.PUT(hashFunction(key), key, value);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}	
					    }
				 			
				 			//finish this task   
	                      currpbq.poll();
	                      synchronized (locks.get(key)) {
	                    	locks.get(key).notifyAll();
						  } 
					}
			  
				});
				t.start();
				req.response().end(); //Do not remove this
			}
		});

		routeMatcher.get("/get", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				final String key = map.get("key");
				final String loc = map.get("loc");
	System.out.println(loc+"....");
				//You may use the following timestamp for ordering requests
				final String timestamp = new Timestamp(System.currentTimeMillis() 
								+ TimeZone.getTimeZone("EST").getRawOffset()).toString();
				
				//basically same logic
				if(!hashMap.containsKey(key)) {
                	PriorityBlockingQueue<String>lbq = new PriorityBlockingQueue<String>(10,timestampComparator);
                	Object lock = new Object();
                	lbq.put(timestamp);
                	locks.put(key, lock);
                	hashMap.put(key, lbq);
                }else {	
                	PriorityBlockingQueue<String>lbq = hashMap.get(key);
                	lbq.put(timestamp);
                }
				

				Thread t = new Thread(new Runnable() {
					public void run() {
						//TODO: Write code for GET operation here.
                        //Each GET operation is handled in a different thread.
                        //Highly recommended that you make use of helper functions.
						PriorityBlockingQueue<String>currpbq = hashMap.get(key);
					 
					    String result ="0";
					    while(!currpbq.peek().equals(timestamp)) {
					    	synchronized (locks.get(key)) {
								 try {
									 locks.get(key).wait();
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							}
					    }
					    
					   
					    // two strategies for fetching the data.
					    // one is decided by parameter, another is decided by the hash when put it ,
					    // which should be the same
					    if(storageType.equals("replication")) {
					    	String location = "";
			                int locationInt = Integer.parseInt(loc);
	
			                switch (locationInt){
			                    case 1:
			                        location = dataCenter1;
			                        break;
			                    case 2:
			                        location = dataCenter2;
			                        break;
			                    case 3:
			                        location = dataCenter3;
			                        break;
			                }
			                
			                try {
								result = KeyValueLib.GET(location, key);
							} catch (IOException e) {
								e.printStackTrace();
							}
							currpbq.poll();
							synchronized (locks.get(key)) {
								locks.get(key).notifyAll();
							}
				   		
							req.response().end(result); //Default response = 0
					
					    }else {
					    	String location = null;
					 
			                int locationInt = Integer.parseInt(loc);
			                switch (locationInt){
			                    case 1:
			                        location = dataCenter1;
			                        break;
			                    case 2:
			                        location = dataCenter2;
			                        break;
			                    case 3:
			                        location = dataCenter3;
			                        break;
			                }
				                
				           if(location == null) {
				        	   location = hashFunction(key);
				           }
						    	
						    try {
								result = KeyValueLib.GET(location, key);
							} catch (Exception e) {
								result = "0";
							} finally {
						    
							if(result == null ) {
								result = "0";
							}
							currpbq.poll();
							synchronized (locks.get(key)) {
								locks.get(key).notifyAll();
							}
							req.response().end(result); //Default response = 0
							}
					   }
					}
				});
				t.start();
			}
		});

		routeMatcher.get("/storage", new Handler<HttpServerRequest>() {
                        @Override
                        public void handle(final HttpServerRequest req) {
                                MultiMap map = req.params();
                                storageType = map.get("storage");
                                if(storageType.equals("sharding")) {
                                	storageType = "sharding";
                                }
                                
                            
                                //This endpoint will be used by the auto-grader to set the 
				//consistency type that your key-value store has to support.
                                //You can initialize/re-initialize the required data structures here
                                
                              
                                req.response().end();
                        }
                });

		routeMatcher.noMatch(new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				req.response().putHeader("Content-Type", "text/html");
				String response = "Not found.";
				req.response().putHeader("Content-Length",
						String.valueOf(response.length()));
				req.response().end(response);
				req.response().close();
			}
		});
		server.requestHandler(routeMatcher);
		server.listen(8080);
	}
}
