package cc.cmu.edu.minisite;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class MySQL {
	private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	private static final String JDBC_URL = "jdbc:mysql://mysql.c5d6atc53kr9.us-east-1.rds.amazonaws.com/mydb";
	private static final String USERNAME = "qiangwan";
	private static final String PASSWORD = "shanggan1021";
	
	public static Connection getConnetion() {
		Connection conn = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return conn;
	}
	
	
	public static Statement getStatement(Connection conn) {
		Statement stmt = null;
		try {
			if(conn != null) {
				stmt = conn.createStatement();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return stmt;
	}
	
	public static ResultSet getResult(Statement stmt, String sql) {
		ResultSet rs = null;
		try {
			if(stmt != null) {
				rs = stmt.executeQuery(sql);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	public static ResultSet getResult(Connection conn, String sql) {
		Statement stmt = getStatement(conn);
		ResultSet rs = getResult(stmt, sql);
		return rs;
		
	}
	
	public static void close(Connection conn){
		 try{
			 if(conn != null){
				 conn.close();
				 conn = null;
			 }
		 }catch(SQLException e){
			 e.printStackTrace();
		 }
	 }
	
	public static void close(Statement stmt){
		 try{
			 if(stmt != null){
				 stmt.close();
				 stmt = null;
			 }
		 }catch(SQLException e){
			 e.printStackTrace();
		 }
	 }
	
	public static void close(ResultSet rs){
		try{
			if(rs != null){
				rs.close();
				rs = null;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
}
