package cc.cmu.edu.minisite;
import java.util.Collections;
import java.util.ArrayList;

public class Follower {
	private static ArrayList<UserProfile>followers;

	public static ArrayList<UserProfile> getFollowers(String id) {

		followers = HBase.getFollowers(id);
		Collections.sort(followers);
		return followers;
	}	
}
