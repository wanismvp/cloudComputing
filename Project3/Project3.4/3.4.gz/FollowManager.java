package cc.cmu.edu.minisite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Stack;

import org.json.JSONArray;
import org.json.JSONObject;

public class FollowManager {
	private static ArrayList<UserProfile> followers;
	private static ArrayList<String> followeesIds;

	final static Comparator<JSONObject> timestampComparator = new Comparator<JSONObject>() {
		@Override
		public int compare(JSONObject o1, JSONObject o2) {
			if (o1.get("timestamp").equals(o2.get("timestamp"))) {
				String pid1 = (String) o1.get("pid");
				String pid2 = (String) o2.get("pid");
				return pid2.compareTo(pid1);
			}
			String t2 = (String) o2.get("timestamp");
			String t1 = (String) o1.get("timestamp");
			return t2.compareTo(t1);
		}
	};

	final static Comparator<Candidate> scoreComparator = new Comparator<Candidate>() {
		@Override
		public int compare(Candidate o1, Candidate o2) {
			if (o1.getCount() == o2.getCount()) {
				return Integer.parseInt(o1.getId()) - Integer.parseInt(o2.getId());
			}
			return o2.getCount() - o1.getCount();
		}
	};

	public static ArrayList<UserProfile> getFollowersProfiles(String id) {
		followers = HBase.getFollowers(id);
		Collections.sort(followers);
		return followers;
	}

	public static ArrayList<String> getFolloweeIds(String id) {
		String[] ids = HBase.getFolloweeID(id).split(",");
		followeesIds = new ArrayList<String>(ids.length);
		Collections.addAll(followeesIds, ids);
		return followeesIds;
	}

	public static JSONArray getFolloweesPosts(String id) {
		PriorityQueue<JSONObject> queue = new PriorityQueue<JSONObject>(10,
				timestampComparator);
		ArrayList<String> followeesIds = getFolloweeIds(id);
		for (String followeeid : followeesIds) {
			JSONArray followeePosts = MongoDB.getPosts(followeeid);
			for (int i = 0; i < followeePosts.length(); ++i) {
				queue.add(followeePosts.getJSONObject(i));
			}
		}

		int size = Math.min(30, queue.size());

		Stack<JSONObject> stack = new Stack<JSONObject>();
		for (int i = 0; i < size; ++i) {
			stack.push(queue.poll());
		}

		JSONArray jsonArray = new JSONArray();
		while (!stack.isEmpty()) {
			jsonArray.put(stack.pop());
		}

		return jsonArray;
	}

	public static ArrayList<UserProfile> getRecommendationProfiles(String id) {
		ArrayList<String> myfolloweesIds = getFolloweeIds(id);
		System.out.println(myfolloweesIds.size());
		HashMap<String, Integer> scores = new HashMap<String, Integer>();
		for (String followeeId : myfolloweesIds) {
			ArrayList<String> followeefloweesids = getFolloweeIds(followeeId);
			System.out.println(followeefloweesids.size());
			for (String followeefloweesid : followeefloweesids) {
				System.out.println(followeefloweesid);
				if (!followeefloweesid.equals(id)) {
					//System.out.println("fuck first level");
					//System.out.println("target " + followeefloweesid);
					
					
					
					if (!myfolloweesIds.contains(followeefloweesid)) {
						//System.out.println("fuck second level");
						if (!scores.containsKey(followeefloweesid)) {
							scores.put(followeefloweesid, 1);
						//	System.out.println("yse");
						} else {
							scores.put(followeefloweesid,
									scores.get(followeefloweesid) + 1);
						//	System.out.println("no");
						}
					}
				}
			}
		}

		System.out.println("size of hashmap is " + scores.size());
		PriorityQueue<Candidate> queue = new PriorityQueue<Candidate>(5, scoreComparator);
		for (Map.Entry<String, Integer> entry : scores.entrySet()) {
			String userid = entry.getKey();
			int score = entry.getValue();
			Candidate candidate = new Candidate();
			candidate.setId(userid);
			candidate.setCount(score);
			queue.add(candidate);
		}

		int size = Math.min(10, queue.size());

		ArrayList<UserProfile> recommendationProfiles = new ArrayList<UserProfile>();
		System.out.println("size if recommendationProfiles"
				+ recommendationProfiles.size());
		for (int i = 0; i < size; i++) {
			Candidate candidate = queue.poll();
			UserProfile userProfile = UserManager.getImgUrlName(candidate
					.getId());
			recommendationProfiles.add(userProfile);
		}
		return recommendationProfiles;
	}
}
