
package cc.cmu.edu.minisite;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;


public class HBase {

    /**
     * The private IP address of HBase master node.
     */
    private static String zkAddr = "172.31.15.244";
    /**
     * The name of your HBase table.
     */
    private static String tableName1 = "links";
    private static String tableName2 = "linksr";
     /**
     * HTable handler.
     */
    private static HTableInterface linkTable1;
    private static HTableInterface linkTable2;
    /**
     * HBase connection.
     */
    private static HConnection conn;
    /**
     * Byte representation of column family.
     */
    private static byte[] bColFamily = Bytes.toBytes("data");
    /**
     * Logger.
     */
    private final static Logger logger = Logger.getRootLogger();
    
    
    /**
     * Initialize HBase connection.
     * @throws IOException
     */
    public static void initializeConnection() {
        // Remember to set correct log level to avoid unnecessary output.
    	try {
    		logger.setLevel(Level.ERROR);
            Configuration conf = HBaseConfiguration.create();
            conf.set("hbase.master", zkAddr + ":60000");
            conf.set("hbase.zookeeper.quorum", zkAddr);
            conf.set("hbase.zookeeper.property.clientport", "2181");
    	    if (!zkAddr.matches("\\d+.\\d+.\\d+.\\d+")) {
    		    System.out.print("HBase not configured!");
    		    return;
    	    }
            conn = HConnectionManager.createConnection(conf);
            linkTable1 = conn.getTable(Bytes.toBytes(tableName1));
            linkTable2 = conn.getTable(Bytes.toBytes(tableName2));
		} catch (IOException e) {
			e.printStackTrace();
		}
        
    }
    /**
     * Clean up resources.
     * @throws IOException
     */
    public  static void cleanup() {
    	try {
    		 if (linkTable1 != null) {
	        	linkTable1.close();
    		 }
    		 
    		 if (linkTable2 != null) {
 	        	linkTable2.close();
     		 }
	        if (conn != null) {
	            conn.close();
	        }
    	}catch(IOException e) {
    		e.printStackTrace();
    	}
       
    }
    

	public static ArrayList<UserProfile> getFollowers(String id) {    
		ArrayList<UserProfile>followerProfiles = new ArrayList<UserProfile>();
		String []followerIds = getFollowerId(id).split(",");
		for (String followerid : followerIds) {
			UserProfile userProfile = getFollowerProfile(followerid);
            //System.out.println(userProfile.getName());
			followerProfiles.add(userProfile);
			
		}
		return followerProfiles;

	}
	private static UserProfile getFollowerProfile(String followerid) {
		UserProfile userProfile =UserManager.getImgUrlName(followerid);
		return userProfile;
		
	}
	private static String getFollowerId(String id) {
    //System.out.println("this is the beginning of getFOllowid function");
		 byte[] bCol = Bytes.toBytes("followerid");
		 Get get = new Get(Bytes.toBytes(id));
		 Result result;
		 String values= "";
		try {
			System.out.println(linkTable1 + "fdsafdsaf");
			result = linkTable1.get(get);
            //System.out.println(result + "this is the getFOllowid function");
		    values = Bytes.toString(result.getValue(bColFamily, bCol));
           // System.out.println(values + "this is the getFOllowid function");
			linkTable1.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return values;
	}
	public static String getFolloweeID(String id) {
		byte[] bCol = Bytes.toBytes("followeeid");
		 Get get = new Get(Bytes.toBytes(id));
		 Result result;
		 String values= "";
		try {
			result = linkTable2.get(get);
           //System.out.println(result + "this is the getFOllowid function");
		    values = Bytes.toString(result.getValue(bColFamily, bCol));
          // System.out.println(values + "this is the getFOllowid function");
			linkTable2.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return values;
	}
}
