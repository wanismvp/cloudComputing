package cc.cmu.edu.minisite;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;



public class RecommendationServlet extends HttpServlet {
	
	public RecommendationServlet () throws Exception {
        /*
        	Your initialization code goes here
         */
		HBase.initializeConnection();
    	MongoDB.initMongoDB();
		
	}

	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) 
			throws ServletException, IOException {

			JSONObject result = new JSONObject();
	        String id = request.getParameter("id");
	        ArrayList<UserProfile>recommendationProfiles = FollowManager.getRecommendationProfiles(id);
	        
	        JSONArray recommendations = new JSONArray();
	        JSONObject recommendation = null;  
	        
	        for(UserProfile userProifle : recommendationProfiles) {
	        	recommendation = new JSONObject();
	        	recommendation.put("name", userProifle.getName());
	        	recommendation.put("profile", userProifle.getImgUrl());
	            //System.out.println(userProifle.getImgUrl());
	        	recommendations.put(recommendation);
	        }
	          
	        result.put("recommendation", recommendations);

		/**
		 * Bonus task:
		 * 
		 * Recommend at most 10 people to the given user with simple collaborative filtering.
		 * 
		 * Store your results in the result object in the following JSON format:
		 * recommendation: [
		 * 		{name:<name_1>, profile:<profile_1>}
		 * 		{name:<name_2>, profile:<profile_2>}
		 * 		{name:<name_3>, profile:<profile_3>}
		 * 		...
		 * 		{name:<name_10>, profile:<profile_10>}
		 * ]
		 * 
		 * Notice: make sure the input has no duplicate!
		 */
        

        
        PrintWriter writer = response.getWriter();
        writer.write(String.format("returnRes(%s)", result.toString()));
        writer.close();

	}

	@Override
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}

