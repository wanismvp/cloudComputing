import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.text.FieldPosition;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeSet;


public class Test {
	
	public static void main(String [] args) throws IOException{
		
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
		BufferedReader br = new BufferedReader(new FileReader(new File("sorted2.csv")));
		String input = "";
		
		PrintWriter printWriter = new PrintWriter("result2.csv");
		String curr = "";
		StringBuilder sb = null;
		
			while( (input = br.readLine()) != null) {
				//System.err.println(curr);
				String [] infos = input.split(",");
				//System.out.println(infos[0] + ":" + infos[1]);
				if(!infos[1].equals(curr)) {
					if(!curr.equals("")) {
						//printWriter.println(sb.toString());
						System.out.println(sb.toString());
					}
					
					curr = infos[1];
					//printWriter.println(sb.toString());
					sb = new StringBuilder();
					sb.append(infos[1] + "\t");
					sb.append(infos[0]+ ",");
				}else {
					
					//System.err.println("ffdsafds");
					sb.append(infos[0] + ",");
				}
			}
			System.out.println(sb.toString());
			//printWriter.println(sb.toString());
	
	}
}
	






