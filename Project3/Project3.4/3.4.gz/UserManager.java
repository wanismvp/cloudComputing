package cc.cmu.edu.minisite;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UserManager {
	private static UserManager instance = new UserManager();
	
	private UserManager() {}
	
	public static UserManager getInstance() {
		return instance;
	}
	
	public static UserProfile login(String id, String password) {
		boolean isValidate = verify(id, password);
		UserProfile userProifle = null;
		if (isValidate) {
			 userProifle = getImgUrlName(id);
		}else {
			userProifle = new UserProfile();
			userProifle.setName("Unauthorized");
			userProifle.setImgUrl("#");
		}
		return userProifle;
	}
	
	public static boolean verify(String id, String password) {
		String sql = "select password from users where userid=" + "\""+ id + "\"";
System.out.println(sql);
		Connection conn = MySQL.getConnetion();
		ResultSet resultSet = MySQL.getResult(conn, sql);
		try {
			if(resultSet == null) {
				return false;
			}else {
				if(resultSet.next()) {
					if(password.equals(resultSet.getString("password"))) {
						return true;
					}else {
						return false;
					}
					
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			MySQL.close(resultSet);
			MySQL.close(conn);
		}
		return false;
	}

	public static UserProfile getImgUrlName(String id) {
		String sql = "select username, imgurl from userinfo where userid=" + id;
		UserProfile userProfile = new UserProfile();
		Connection conn = MySQL.getConnetion();
		ResultSet resultSet = MySQL.getResult(conn, sql);
		try {
			if(resultSet.next()) {
				userProfile.setName(resultSet.getString("username"));
				userProfile.setImgUrl(resultSet.getString("imgurl"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			MySQL.close(resultSet);
			MySQL.close(conn);
		}
		return userProfile;
	}
}