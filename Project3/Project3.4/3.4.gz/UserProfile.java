package cc.cmu.edu.minisite;

public class UserProfile implements Comparable<UserProfile>{
	private String name;
	private String imgUrl;
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	@Override
	public int compareTo(UserProfile o) {
		if(this.name.equals(o.name)) {
			return this.imgUrl.compareTo(o.imgUrl);
		}
		return this.name.compareTo(o.name);
	}
}
