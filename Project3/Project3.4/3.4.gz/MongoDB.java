package cc.cmu.edu.minisite;

import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;




import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoDatabase;

public class MongoDB {
	private static MongoClient mongoClient = null;
 	private static MongoDatabase db = null;
	
	public static void initMongoDB() {
		mongoClient = new MongoClient("ec2-52-207-240-80.compute-1.amazonaws.com", 27017);
		db = mongoClient.getDatabase("posts");
	}
	
	public static JSONArray getPosts (String id) {
		 FindIterable<Document> iterable = db.getCollection("post").find(
	                new Document("uid", Integer.parseInt(id))).sort(new Document("timestamp",1));
	        final JSONArray jsonArray = new JSONArray();
	        iterable.forEach(new Block<Document>() {
	            @Override
	            public void apply(final Document document) {
	                jsonArray.put(new JSONObject(document.toJson().toString()));
	            }
	        });
		return jsonArray;
	}

}
