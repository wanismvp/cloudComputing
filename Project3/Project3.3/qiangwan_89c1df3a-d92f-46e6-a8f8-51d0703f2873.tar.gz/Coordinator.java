import java.io.IOException;
import java.util.HashMap;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Map;

import org.vertx.java.core.Handler;
import org.vertx.java.core.MultiMap;
import org.vertx.java.core.http.HttpServer;
import org.vertx.java.core.http.HttpServerRequest;
import org.vertx.java.core.http.RouteMatcher;
import org.vertx.java.platform.Verticle;

//ignore my style of system.println , just for debugging and easier to see iti
public class Coordinator extends Verticle {

	// This integer variable tells you what region you are in
	// 1 for US-E, 2 for US-W, 3 for Singapore
	private static int region = KeyValueLib.region;

	// Default mode: Strongly consistent
	// Options: strong, eventual
	private static String consistencyType = "strong";

	/**
	 * TODO: Set the values of the following variables to the DNS names of your
	 * three dataCenter instances. Be sure to match the regions with their DNS!
	 * Do the same for the 3 Coordinators as well.
	 */
	private static final String dataCenterUSE = "ec2-54-88-200-104.compute-1.amazonaws.com";
	private static final String dataCenterUSW = "ec2-52-87-246-160.compute-1.amazonaws.com";
	private static final String dataCenterSING = "ec2-52-91-220-27.compute-1.amazonaws.com";

	private static final String coordinatorUSE = "ec2-54-173-22-29.compute-1.amazonaws.com";
	private static final String coordinatorUSW = "ec2-52-90-145-179.compute-1.amazonaws.com";
	private static final String coordinatorSING = "ec2-52-201-230-230.compute-1.amazonaws.com";
	
	private int hashFunction(String key) {
		if(key.equals("a")) {
			return 1;
		}else if(key.equals("b")) {
			return 2;
		}else if(key.equals("c")) {
			return 3;
		}else{
			int code = 0;
			for(int i=0; i<key.length(); i++) {
				code += key.charAt(i);
			}
			if(code%3 == 0) {
				return 1;
			}else if(code%3 == 1) {
				return 2;
			}else {
				return 3;
			}
		}
	}
	
	private String processEventualGetRequest(String key,
			Long timestamp) {
		String result = "";
		try {
			if(region == 1) {
				result = KeyValueLib.GET(dataCenterUSE, key, String.valueOf(timestamp), consistencyType);
			}else if(region == 2) {
				result = KeyValueLib.GET(dataCenterUSW, key, String.valueOf(timestamp), consistencyType);
			}else if(region == 3) {
				result = KeyValueLib.GET(dataCenterSING, key, String.valueOf(timestamp), consistencyType);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	private void processEventualPutRequest(String key,
			String value, Long timestamp, String forwarded,
			String forwardedRegion) {
		int target = hashFunction(key);
		if(forwarded != null) {
			try {
				KeyValueLib.PUT(dataCenterUSE, key, value, String.valueOf(timestamp), consistencyType);
				KeyValueLib.PUT(dataCenterUSW, key, value, String.valueOf(timestamp), consistencyType);
				KeyValueLib.PUT(dataCenterSING, key, value, String.valueOf(timestamp), consistencyType);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else if(region != target) {
			try {
				if(target == 1) {
					KeyValueLib.FORWARD(coordinatorUSE, key, value, String.valueOf(timestamp));
				}else if(target == 2) {
					KeyValueLib.FORWARD(coordinatorUSW, key, value, String.valueOf(timestamp));
				}else if(target == 3) {
					KeyValueLib.FORWARD(coordinatorSING, key, value, String.valueOf(timestamp));
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else {
			try {
				KeyValueLib.PUT(dataCenterUSE, key, value, String.valueOf(timestamp), consistencyType);
				KeyValueLib.PUT(dataCenterUSW, key, value, String.valueOf(timestamp), consistencyType);
				KeyValueLib.PUT(dataCenterSING, key, value, String.valueOf(timestamp), consistencyType);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}

	}
	
	private String processStrongGetRequest(String key, Long timestamp) {
System.out.println("get get request" + key + " : " + timestamp);
		String result = "";
		try {
			if(region == 1) {
				result = KeyValueLib.GET(dataCenterUSE, key, String.valueOf(timestamp), consistencyType);
			}else if(region == 2) {
				result = KeyValueLib.GET(dataCenterUSW, key, String.valueOf(timestamp), consistencyType);
			}else if(region == 3) {
				result = KeyValueLib.GET(dataCenterSING, key, String.valueOf(timestamp), consistencyType);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	private void processStrongPutRequest(String key, String value,
			Long timestamp, String forwarded,
			String forwardedRegion) {
System.out.println("get put request " + key + ":" + value + " : " + timestamp);
			int target = hashFunction(key);
			if(forwarded != null) {
				try {
					KeyValueLib.PUT(dataCenterUSE, key, value, String.valueOf(timestamp), consistencyType);
					KeyValueLib.PUT(dataCenterUSW, key, value, String.valueOf(timestamp), consistencyType);
					KeyValueLib.PUT(dataCenterSING, key, value, String.valueOf(timestamp), consistencyType);
					KeyValueLib.COMPLETE(key, String.valueOf(timestamp));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}else if(region != target) {
				try {
					if(target == 1) {
						KeyValueLib.AHEAD(key, String.valueOf(timestamp));
						KeyValueLib.FORWARD(coordinatorUSE, key, value, String.valueOf(timestamp));
					}else if(target == 2) {
						KeyValueLib.AHEAD(key, String.valueOf(timestamp));
						KeyValueLib.FORWARD(coordinatorUSW, key, value, String.valueOf(timestamp));
					}else if(target == 3) {
						KeyValueLib.AHEAD(key, String.valueOf(timestamp));
						KeyValueLib.FORWARD(coordinatorSING, key, value, String.valueOf(timestamp));
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}else {
				try {
					KeyValueLib.AHEAD(key, String.valueOf(timestamp));
					KeyValueLib.PUT(dataCenterUSE, key, value, String.valueOf(timestamp), consistencyType);
					KeyValueLib.PUT(dataCenterUSW, key, value, String.valueOf(timestamp), consistencyType);
					KeyValueLib.PUT(dataCenterSING, key, value, String.valueOf(timestamp), consistencyType);
					KeyValueLib.COMPLETE(key, String.valueOf(timestamp));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}		
			}
	}

	@Override
	public void start() {
		KeyValueLib.dataCenters.put(dataCenterUSE, 1);
		KeyValueLib.dataCenters.put(dataCenterUSW, 2);
		KeyValueLib.dataCenters.put(dataCenterSING, 3);
		KeyValueLib.coordinators.put(coordinatorUSE, 1);
		KeyValueLib.coordinators.put(coordinatorUSW, 2);
		KeyValueLib.coordinators.put(coordinatorSING, 3);
		final RouteMatcher routeMatcher = new RouteMatcher();
		final HttpServer server = vertx.createHttpServer();
		server.setAcceptBacklog(32767);
		server.setUsePooledBuffers(true);
		server.setReceiveBufferSize(4 * 1024);

		routeMatcher.get("/put", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				final String key = map.get("key");
				final String value = map.get("value");
				final Long timestamp = Long.parseLong(map.get("timestamp"));
				final String forwarded = map.get("forward");
				final String forwardedRegion = map.get("region");
				Thread t = new Thread(new Runnable() {
					public void run() {
					/* TODO: Add code for PUT request handling here
					 * Each operation is handled in a new thread.
					 * Use of helper functions is highly recommended */
						if(consistencyType.equals("strong")) {
							processStrongPutRequest(key, value, timestamp, forwarded, forwardedRegion);
						}else {
							System.out.println("this is eventual put test ............");
							processEventualPutRequest(key, value, timestamp, forwarded, forwardedRegion);
						}
					}

					
					
				});
				t.start();
				req.response().end(); // Do not remove this
			}
		});

		routeMatcher.get("/get", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				final String key = map.get("key");
				final Long timestamp = Long.parseLong(map.get("timestamp"));
				Thread t = new Thread(new Runnable() {
					public void run() {
					/* TODO: Add code for GET requests handling here
					 * Each operation is handled in a new thread.
					 * Use of helper functions is highly recommended */
						String response = "";
						if(consistencyType.equals("strong")) {
							response = processStrongGetRequest(key, timestamp);
						}else {
System.out.println("this is eventual get test ............");
							response = processEventualGetRequest(key, timestamp);
						}
						req.response().end(response);
					}

					
  
				});
				t.start();
			}
		});
		/* This endpoint is used by the grader to change the consistency level */
		routeMatcher.get("/consistency", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				consistencyType = map.get("consistency");
				req.response().end();
			}
		});
		routeMatcher.noMatch(new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				req.response().putHeader("Content-Type", "text/html");
				String response = "Not found.";
				req.response().putHeader("Content-Length",
						String.valueOf(response.length()));
				req.response().end(response);
				req.response().close();
			}
		});
		server.requestHandler(routeMatcher);
		server.listen(8080);
	}
}
