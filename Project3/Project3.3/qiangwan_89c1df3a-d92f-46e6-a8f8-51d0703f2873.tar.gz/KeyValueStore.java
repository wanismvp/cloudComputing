import java.util.Comparator;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

import org.omg.PortableInterceptor.LOCATION_FORWARD;
import org.vertx.java.core.Handler;
import org.vertx.java.core.MultiMap;
import org.vertx.java.core.http.HttpServer;
import org.vertx.java.core.http.HttpServerRequest;
import org.vertx.java.core.http.RouteMatcher;
import org.vertx.java.platform.Verticle;

//ignore my style syso prinln it is for debugging and easier to delete
class Data {
	public String value;
	public Long timestamp;
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	
}
public class KeyValueStore extends Verticle {

	/* TODO: Add code to implement your backend storage */

	@Override
	public void start() {
		final KeyValueStore keyValueStore = new KeyValueStore();
		final RouteMatcher routeMatcher = new RouteMatcher();
		final HttpServer server = vertx.createHttpServer();
		server.setAcceptBacklog(32767);
		server.setUsePooledBuffers(true);
		server.setReceiveBufferSize(4 * 1024);
		
		ConcurrentHashMap<String, String>dababase = new ConcurrentHashMap<String, String>();
		HashMap<String, Data>database2 = new HashMap<String, Data>();
		//for each key, I need a thread-safe priority blocking queue
		ConcurrentHashMap<String, PriorityBlockingQueue<Long>>hashMap = new ConcurrentHashMap<String, PriorityBlockingQueue<Long>>();
		//for each key, I also need a lock
		ConcurrentHashMap<String, Object>locks = new ConcurrentHashMap<String, Object>();

//		final Comparator<Long>timestampComparator = new Comparator<Long>() {
//			@Override
//			public int compare(Long o1, Long o2) {
//				if(o1 - o2 > 0) {
//					return 1;
//				}else if(o1 - o2 < 0) {
//					return -1;
//				}else {
//					return 0;
//				}
//			}
//		};

		routeMatcher.get("/put", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				String key = map.get("key");
				String value = map.get("value");
				String consistency = map.get("consistency");
				Integer region = Integer.parseInt(map.get("region"));

				Long timestamp = Long.parseLong(map.get("timestamp"));

				/* TODO: Add code here to handle the put request
					 Remember to use the explicit timestamp if needed! */
System.out.println("put data " + key + ":" + value + " : " + timestamp);
//				if(!hashMap.containsKey(key)) {
//                	PriorityBlockingQueue<String>lbq = new PriorityBlockingQueue<String>(10,timestampComparator);
//                	//lbq.put(String.valueOf(timestamp));
//                	hashMap.put(key, lbq);
//                	//dababase.put(key, value);
//                	
//                	Object lock = new Object();
//                	locks.put(key,lock);
//                }else {	
//                // if i have the queue for the queue, just put the task
//                	PriorityBlockingQueue<String>lbq = hashMap.get(key);
//                	//dababase.put(key, value);
//                	//lbq.put(String.valueOf(timestamp));
//                }
				if(consistency.equals("strong")) {
					Thread t = new Thread(new Runnable() {
						@Override
						public void run() {
							PriorityBlockingQueue<Long>lbq = hashMap.get(key);
						    while(!lbq.peek().equals(timestamp)) {
						    	System.out.println("put dead lock???");
						    	synchronized (locks.get(key)) {
									 try {
										 locks.get(key).wait();
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
								}
						    }
							 System.out.println("put data " + key + " : " + value + " " + timestamp);		 
						     dababase.put(key, value);
	
							 //currpbq.poll();
	//	                     synchronized (locks.get(key)) {
	//	                    	 locks.get(key).notifyAll();
	//						 } 
						}
					});
					t.start();
				}else {
					if(!database2.containsKey(key)) {
	                	Data data = new Data();
	                	data.setTimestamp(timestamp);
	                	data.setValue(value);
	                	database2.put(key, data);
	                	System.out.println("eventual no data " + key + " : "+ value + " : " +timestamp);
					}else {	
						Data lastData = database2.get(key);
						if(timestamp > lastData.getTimestamp()) {
							Data data = new Data();
		                	data.setTimestamp(timestamp);
		                	data.setValue(value);
		                	database2.put(key, data);
		                	System.out.println("eventual updata data " + key + " : "+ value + " : " +timestamp);
						}
                }
					
				}
				String response = "stored";
				req.response().putHeader("Content-Type", "text/plain");
				req.response().putHeader("Content-Length",
						String.valueOf(response.length()));
				req.response().end(response);
				req.response().close();
			}
		});
		routeMatcher.get("/get", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				final String key = map.get("key");
				String consistency = map.get("consistency");
				final Long timestamp = Long.parseLong(map.get("timestamp"));
System.out.println("get get request" + key + " : " + timestamp);

				/* TODO: Add code here to handle the get request
					 Remember that you may need to do some locking for this */
				if(consistency.equals("strong")) {
	
					if(!hashMap.containsKey(key)) {
	                	PriorityBlockingQueue<Long>lbq = new PriorityBlockingQueue<Long>();
	                	lbq.put(timestamp);
	                	hashMap.put(key, lbq);
	                	
	                	Object lock = new Object();
	                	locks.put(key, lock);
	                }else {	
	                	PriorityBlockingQueue<Long>lbq = hashMap.get(key);
	                	lbq.put(timestamp);
	                }
					
					Thread t = new Thread(new Runnable() {
						@Override
						public void run() {
							PriorityBlockingQueue<Long>currpbq = hashMap.get(key);
						    String response ="0";
						    while(!currpbq.peek().equals(timestamp)) {
						    	synchronized (locks.get(key)) {
									 try {
										 locks.get(key).wait();
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
								}
						    	System.out.println("get dead lock");
						    }
						    response = dababase.get(key); 
	System.out.println("get the value of " + key + " : " + response);
						    currpbq.poll();
							synchronized (locks.get(key)) {
								locks.get(key).notifyAll();
							}
							
						    req.response().putHeader("Content-Type", "text/plain");
							if (response != null)
								req.response().putHeader("Content-Length",
										String.valueOf(response.length()));
		
							req.response().end(response);
							req.response().close();
						   
						}
					});
					
				     t.start();
				}else {
					String response = "";
					Data data  = database2.get(key);
					
					if(data == null) {
						response = "0";
					}else {
						response = data.getValue();
					}
					req.response().putHeader("Content-Type", "text/plain");
					if (response != null) 
						req.response().putHeader("Content-Length",
								String.valueOf(response.length()));

					req.response().end(response);
					req.response().close();

				}
					
			}
		});
		// Clears this stored keys. Do not change this
		routeMatcher.get("/reset", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				/* TODO: Add code to here to flush your datastore. This is MANDATORY */
System.out.println("\nget reset request\n");
				req.response().putHeader("Content-Type", "text/plain");
				
				dababase.clear();
				hashMap.clear();
				locks.clear();
				database2.clear();
				
				req.response().end();
				req.response().close();
			}
		});
		// Handler for when the AHEAD is called
		routeMatcher.get("/ahead", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				String key = map.get("key");
System.out.println("ahead request" + key);
				final Long timestamp = Long.parseLong(map.get("timestamp"));
				
				if(!hashMap.containsKey(key)) {
                	PriorityBlockingQueue<Long>lbq = new PriorityBlockingQueue<Long>();
                	lbq.put(timestamp);
                	hashMap.put(key, lbq);
System.out.println("no key: " + key + " : " + timestamp);
                	
                	Object lock = new Object();
                	locks.put(key,lock);
                }else {
                	PriorityBlockingQueue<Long>lbq = hashMap.get(key);
                	lbq.put(timestamp);
System.out.println("has key: " + key + " : " + timestamp);                	
                	//hashMap.put(key, lbq);
                }
				
				/* TODO: Add code to handle the signal here if you wish */
				req.response().putHeader("Content-Type", "text/plain");
				req.response().end();
				req.response().close();
			} 
		});
		// Handler for when the COMPLETE is called
		routeMatcher.get("/complete", new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				MultiMap map = req.params();
				String key = map.get("key");
System.out.println("get complete request" + key);
				final Long timestamp = Long.parseLong(map.get("timestamp"));
				/* TODO: Add code to handle the signal here if you wish */
				PriorityBlockingQueue<Long>currpbq = hashMap.get(key);
				//currpbq.remove(String.valueOf(timestamp));
				currpbq.poll();
System.out.println("complete " + key + " : " + timestamp);
                synchronized (locks.get(key)) {
                	locks.get(key).notifyAll();
                } 
				
				req.response().putHeader("Content-Type", "text/plain");
				req.response().end();
				req.response().close();
			}
		});
		routeMatcher.noMatch(new Handler<HttpServerRequest>() {
			@Override
			public void handle(final HttpServerRequest req) {
				req.response().putHeader("Content-Type", "text/html");
				String response = "Not found.";
				req.response().putHeader("Content-Length",
						String.valueOf(response.length()));
				req.response().end(response);
				req.response().close();
			}
		});
		server.requestHandler(routeMatcher);
		server.listen(8080);
	}
}
