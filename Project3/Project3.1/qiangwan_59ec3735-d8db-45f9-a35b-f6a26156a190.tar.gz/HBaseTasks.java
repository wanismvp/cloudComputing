import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.IOException;

public class HBaseTasks {

    /**
     * The private IP address of HBase master node.
     */
    private static String zkAddr = "172.31.13.232";
    /**
     * The name of your HBase table.
     */
    private static String tableName = "songdata";
    /**
     * HTable handler.
     */
    private static HTableInterface songsTable;
    /**
     * HBase connection.
     */
    private static HConnection conn;
    /**
     * Byte representation of column family.
     */
    private static byte[] bColFamily = Bytes.toBytes("data");
    /**
     * Logger.
     */
    private final static Logger logger = Logger.getRootLogger();


    /**
     * Initialize HBase connection.
     * @throws IOException
     */
    private static void initializeConnection() throws IOException {
        // Remember to set correct log level to avoid unnecessary output.
        logger.setLevel(Level.ERROR);
        Configuration conf = HBaseConfiguration.create();
        conf.set("hbase.master", zkAddr + ":60000");
        conf.set("hbase.zookeeper.quorum", zkAddr);
        conf.set("hbase.zookeeper.property.clientport", "2181");
	    if (!zkAddr.matches("\\d+.\\d+.\\d+.\\d+")) {
		    System.out.print("HBase not configured!");
		    return;
	    }
        conn = HConnectionManager.createConnection(conf);
        songsTable = conn.getTable(Bytes.toBytes(tableName));
    }

    /**
     * Clean up resources.
     * @throws IOException
     */
    private static void cleanup() throws IOException {
        if (songsTable != null) {
            songsTable.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    /**
     * You should complete the missing parts in the following method. Feel free to add helper functions if necessary.
     *
     * For all questions, output your answer in ONE single line, i.e. use System.out.print().
     *
     * @param args The arguments for main method.
     */
    public static void main(String[] args) throws IOException {
        initializeConnection();
        switch (args[0]) {
            case "demo":
                demo();
                break;
            case "q17":
                q17();
                break;
            case "q18":
                q18();
                break;
            case "q19":
                q19();
                break;
            case "q20":
                q20();
                break;
            case "q21":
                q21();
        }
        cleanup();
    }

    /**
     * This is a demo of how to use HBase Java API. It will print all the artist_names starting with "The Beatles".
     * @throws IOException
     */
    private static void demo() throws IOException {
        Scan scan = new Scan();
        byte[] bCol = Bytes.toBytes("artist_name");
        scan.addColumn(bColFamily, bCol);
        RegexStringComparator comp = new RegexStringComparator("^The Beatles.*");
        Filter filter = new SingleColumnValueFilter(bColFamily, bCol, CompareFilter.CompareOp.EQUAL, comp);
        scan.setFilter(filter);
        scan.setBatch(10);
        ResultScanner rs = songsTable.getScanner(scan);
        int count = 0;
        for (Result r = rs.next(); r != null; r = rs.next()) {
            count ++;
            System.out.println(Bytes.toString(r.getValue(bColFamily, bCol)));
        }
        System.out.println("Scan finished. " + count + " match(es) found.");
        rs.close();
    }

    /**
     * Question 17.
     *
     * What was that song whose name started with "Total" and ended with "Water"?
     * Write an HBase query that finds the track that the person is looking for.
     * The title starts with "Total" and ends with "Water", both are case sensitive.
     * Print the track title(s) in a single line.
     *
     * You are allowed to make changes such as modifying method name, parameter list and/or return type.
     */
    private static void q17() throws IOException{
        Scan scan = new Scan();
        byte[] bCol = Bytes.toBytes("title");
        scan.addColumn(bColFamily, bCol);
        RegexStringComparator comp = new RegexStringComparator("^Total(.)*Water$");
        Filter filter = new SingleColumnValueFilter(bColFamily, bCol, CompareFilter.CompareOp.EQUAL, comp);
        scan.setFilter(filter);
        scan.setBatch(10);
        ResultScanner rs = songsTable.getScanner(scan);
        int count = 0;
        for (Result r = rs.next(); r != null; r = rs.next()) {
            count ++;
            System.out.println(Bytes.toString(r.getValue(bColFamily, bCol)));
        }
        rs.close();

    }

    /**
     * Question 18.
     *
     * I don't remember the exact title, it was that song by "Kanye West", and the
     * title started with either "Apologies" or "Confessions". Not sure which...
     * Write an HBase query that finds the track that the person is looking for.
     * The artist_name contains "Kanye West", and the title starts with either
     * "Apologies" or "Confessions" (Case sensitive).
     * Print the track title(s) in a single line.
     *
     * You are allowed to make changes such as modifying method name, parameter list and/or return type.
     */
    private static void q18() throws IOException{
        Scan scan = new Scan();
        FilterList filterList = new FilterList();

        byte[] bColTitle = Bytes.toBytes("title");
        byte[] bColArtistName = Bytes.toBytes("artist_name");

        scan.addColumn(bColFamily, bColTitle);
        scan.addColumn(bColFamily, bColArtistName);



        RegexStringComparator compTitle = new RegexStringComparator("^(Apologies|Confessions)");
        Filter filterTitle = new SingleColumnValueFilter(bColFamily, bColTitle, CompareFilter.CompareOp.EQUAL, compTitle);

        RegexStringComparator compArtistName = new RegexStringComparator("(.)*(Kanye West)(.)*");
        Filter filterArtistName = new SingleColumnValueFilter(bColFamily, bColArtistName, CompareFilter.CompareOp.EQUAL, compArtistName);

        filterList.addFilter(filterTitle);
        filterList.addFilter(filterArtistName);

        scan.setFilter(filterList);
        scan.setBatch(10);

        ResultScanner rs = songsTable.getScanner(scan);
        int count = 0;
        for (Result r = rs.next(); r != null; r = rs.next()) {
            count ++;
            System.out.println(Bytes.toString(r.getValue(bColFamily, bColTitle)));
        }
        rs.close();

    }

    /**
     * Question 19.
     *
     * There was that new track by "Bob Marley" that was really long. Do you know?
     * Write an HBase query that finds the track the person is looking for.
     * The artist_name has a prefix of "Bob Marley", duration no less than 400,
     * and year 2000 and onwards (Case sensitive).
     * Print the track title(s) in a single line.
     *
     * You are allowed to make changes such as modifying method name, parameter list and/or return type.
     */
    private static void q19() throws IOException{

        Scan scan = new Scan();
        FilterList filterList = new FilterList();

        byte[] bColTitle = Bytes.toBytes("title");
        byte[] bColArtistName = Bytes.toBytes("artist_name");
        byte[] bColDuration = Bytes.toBytes("duration");
        byte[] bColYear = Bytes.toBytes("year");

        scan.addColumn(bColFamily, bColTitle);
        scan.addColumn(bColFamily, bColArtistName);
        scan.addColumn(bColFamily, bColDuration);
        scan.addColumn(bColFamily, bColYear);



        RegexStringComparator compArtistName = new RegexStringComparator("^(Bob Marley)");
        Filter filterArtistName = new SingleColumnValueFilter(bColFamily, bColArtistName, CompareFilter.CompareOp.EQUAL, compArtistName);

        RegexStringComparator compDuration = new RegexStringComparator("^[^0123]");
        Filter filterDuration = new SingleColumnValueFilter(bColFamily, bColDuration, CompareFilter.CompareOp.EQUAL, compDuration);

        RegexStringComparator compYear = new RegexStringComparator("^[2-9](?!10$)[0-9][0-9]\\d+$");
        Filter filterYear = new SingleColumnValueFilter(bColFamily, bColYear, CompareFilter.CompareOp.EQUAL, compYear);



        filterList.addFilter(filterDuration);
        filterList.addFilter(filterArtistName);
        filterList.addFilter(filterYear);

        scan.setFilter(filterList);
        scan.setBatch(10);
        ResultScanner rs = songsTable.getScanner(scan);
        int count = 0;
        for (Result r = rs.next(); r != null; r = rs.next()) {
            count ++;
            System.out.println(Bytes.toString(r.getValue(bColFamily, bColTitle)));
        }
        rs.close();

    }

    /**
     * Question 20.
     *
     * I heard a really great song about "Family" by this really cute singer,
     * I think his name was "Consequence" or something...
     * Write an HBase query that finds the track the person is looking for.
     * The track has an artist_hotttnesss of at least 1, and the artist_name
     * contains "Consequence". Also, the title contains "Family" (Case sensitive).
     * Print the track title(s) in a single line.
     *
     * You are allowed to make changes such as modifying method name, parameter list and/or return type.
     */
    private static void q20() throws IOException{
        Scan scan = new Scan();
        FilterList filterList = new FilterList();

        byte[] bColTitle = Bytes.toBytes("title");
        byte[] bColArtistName = Bytes.toBytes("artist_name");
        byte[] bColArtistHotttnesss = Bytes.toBytes("artist_hotttnesss");
    

        scan.addColumn(bColFamily, bColTitle);
        scan.addColumn(bColFamily, bColArtistName);
        scan.addColumn(bColFamily, bColArtistHotttnesss);
        

        RegexStringComparator compTitle = new RegexStringComparator("(.)*(Family)(.)*");
        Filter filterTitle = new SingleColumnValueFilter(bColFamily, bColTitle, CompareFilter.CompareOp.EQUAL, compTitle);

        RegexStringComparator compArtistName = new RegexStringComparator("(.)*(Consequence)(.)*");
        Filter filterArtistName = new SingleColumnValueFilter(bColFamily, bColArtistName, CompareFilter.CompareOp.EQUAL, compArtistName);


        RegexStringComparator compArtistHotttnesss = new RegexStringComparator("^((?!0\\.).).*$");
        Filter filterArtistHotttnesss = new SingleColumnValueFilter(bColFamily, bColArtistHotttnesss, CompareFilter.CompareOp.EQUAL, compArtistHotttnesss);


        filterList.addFilter(filterTitle);
        filterList.addFilter(filterArtistName);
        filterList.addFilter(filterArtistHotttnesss);


        scan.setFilter(filterList);
        scan.setBatch(10);
        ResultScanner rs = songsTable.getScanner(scan);
        int count = 0;
        for (Result r = rs.next(); r != null; r = rs.next()) {
            count ++;
            System.out.println(Bytes.toString(r.getValue(bColFamily, bColTitle)));
        }
        rs.close();
    }

    /**
     * Question 21.
     *
     * Hey what was that "Love" song that "Gwen Guthrie" came out with in 1990?
     * No, no, it wasn't the sad one, nothing "Bitter" or "Never"...
     * Write an HBase query that finds the track the person is looking for.
     * The track has an artist_name prefix of "Gwen Guthrie", the title contains "Love"
     * but does NOT contain "Bitter" or "Never", the year equals to 1990.
     * Print the track title(s) in a single line.
     *
     * You are allowed to make changes such as modifying method name, parameter list and/or return type.
     */

    private static void q21() throws IOException{
        Scan scan = new Scan();
        FilterList filterList = new FilterList();

        byte[] bColTitle1 = Bytes.toBytes("title");
        byte[] bColTitle2 = Bytes.toBytes("title");
        byte[] bColTitle3 = Bytes.toBytes("title");
        byte[] bColArtistName = Bytes.toBytes("artist_name");
        byte[] bColYear = Bytes.toBytes("year");

        scan.addColumn(bColFamily, bColTitle1);
        scan.addColumn(bColFamily, bColTitle2);
        scan.addColumn(bColFamily, bColTitle3);
        scan.addColumn(bColFamily, bColArtistName);
        scan.addColumn(bColFamily, bColYear);

        RegexStringComparator compTitle1 = new RegexStringComparator("(.)*(Love)(.)*");
        Filter filterTitle1 = new SingleColumnValueFilter(bColFamily, bColTitle1, CompareFilter.CompareOp.EQUAL, compTitle1);

        RegexStringComparator compTitle2 = new RegexStringComparator("^((?!Bitter).)*$");
        Filter filterTitle2 = new SingleColumnValueFilter(bColFamily, bColTitle2, CompareFilter.CompareOp.EQUAL, compTitle2);

        RegexStringComparator compTitle3 = new RegexStringComparator("^((?!Never).)*$");
        Filter filterTitle3 = new SingleColumnValueFilter(bColFamily, bColTitle3, CompareFilter.CompareOp.EQUAL, compTitle3);

        RegexStringComparator compArtistName = new RegexStringComparator("^(Gwen Guthrie)");
        Filter filterArtistName = new SingleColumnValueFilter(bColFamily, bColArtistName, CompareFilter.CompareOp.EQUAL, compArtistName);

        RegexStringComparator compYear = new RegexStringComparator("^1990$");
        Filter filterYear = new SingleColumnValueFilter(bColFamily, bColYear, CompareFilter.CompareOp.EQUAL, compYear);


        filterList.addFilter(filterTitle1);
        filterList.addFilter(filterTitle2);
        filterList.addFilter(filterTitle3);
        filterList.addFilter(filterArtistName);
        filterList.addFilter(filterYear);
        scan.setFilter(filterList);
        scan.setBatch(10);
        ResultScanner rs = songsTable.getScanner(scan);
        int count = 0;
        for (Result r = rs.next(); r != null; r = rs.next()) {
            count ++;
            System.out.println(Bytes.toString(r.getValue(bColFamily, bColTitle1)));
        }
        rs.close();
    }
}
