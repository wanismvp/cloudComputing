import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoadBalancer {
	private static final int THREAD_POOL_SIZE = 4;
	private final ServerSocket socket;
	private final DataCenterInstance[] instances; 
	private float CPUUtilizations [];

	public LoadBalancer(ServerSocket socket, DataCenterInstance[] instances) {
		this.socket = socket;
		this.instances = instances;
		
	}

	// Complete this function
         public void start() throws IOException {
         	ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
         	int size = instances.length;
         	int count = 0;
         	while(true) {
      
                 // By default, it will send all requests to the first instance
        
                 Runnable requestHandler = new RequestHandler(socket.accept(), instances[count%size]);
                 executorService.execute(requestHandler);
                 count ++;
               }
        } 
        
	


}
