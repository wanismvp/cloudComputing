import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class LoadBalancer {
	private static int target = 0;
	private static final int THREAD_POOL_SIZE = 4;
	private final ServerSocket socket;
	private final DataCenterInstance[] instances;
	private float CPUUtilizations [];
	private int [] status = {0,0,0}; 

	class Util implements Runnable {
		int index;
		public Util(int index) {
			this.index = index;
		}
		
		public void run() {
			//status[index] = -1;
		//	System.out.println("beging create new life ..........");
			
			String  dcDNS = VMUtil.createDC();
			
		//	System.out.println("*************create one!!!!!!!!!!!!!!");
			System.out.println(dcDNS + "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			
			
			
			try {
				Thread.sleep(1000*150);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			while(checkOne("http://" + dcDNS)){
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("http://" + dcDNS + "&&&&&&&&&&&&&&&&&");

			}
			
			
			
			instances[index] = new DataCenterInstance("hi", "http://" + dcDNS);
			System.out.println("create" + dcDNS);
			status[index] = 0;
			System.out.println("gooooooooooooooood      new life!!!!!!");
			
		} 
		
	}
	
	public LoadBalancer(ServerSocket socket, DataCenterInstance[] instances) {
		this.socket = socket;
		this.instances = instances;
		CPUUtilizations = new float[3];
		
	}

	// Complete this function
         public void start() throws IOException {
         	int size = instances.length;
         	ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
         	int count = 0;
         	int intervalHealth = 85; 
         	int cpuHealth = 10;
         	while(true) {
         	     target = count %size;
         	     
         		 if(count % cpuHealth == 0) {
         			 for(int i=0; i < instances.length; i++) {
         				 if(status[i] == 0) {
         					CPUUtilizations[i] = getCPUUtilization(instances[i].getUrl());
         				 }else {
         					CPUUtilizations[i] = 1000;
         				 }
         			 }
         			 
                    target = findMin(CPUUtilizations);      
         		 }

         		 if( count%intervalHealth == 0) {
                	 
                	 //System.out.println("check.............");
                	 check();
                     	 
                	 //System.out.println("finish checking ......");
                	 for(int i=0; i<status.length; i++) {
                		 if(status[i] == 2) {
                			 status[i] =-1;
                			 Util util = new Util(i);
                			 new Thread(util).start();
                		 }
                	 }
                 
                }


                if(status[target] != 0) {
                	 target = target + 1;
                 }
               
                               

	            Runnable requestHandler = new RequestHandler(socket.accept(), instances[target%size]);
	            executorService.execute(requestHandler);  
                count ++;
            }
        } 
         
     private  void check(){
 		for(int i = 0; i<instances.length; i++) {
 			System.out.println(instances[i].getUrl()+ " status" + status[i] + "....");
 			if(status[i] != -1&&!checkOne(instances[i].getUrl())) {
 				status[i] += 1;
 				System.out.println(instances[i].getUrl() + "is dead ??????????");
 			}
 			
 		}
 		
 		System.out.println("finish checking .....");
 	}
        
	private boolean checkOne(String address) {
		try {
			URL url = new URL(address);
System.out.println("this cpu url is  : " + address );
			HttpURLConnection connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod("GET");
			int responseCode = connection.getResponseCode();
			System.err.println(responseCode);
			if(responseCode != 200) {
				return false;
			}
		} catch (IOException e) {
			System.out.println("dead");
			return false;
		}
		   return true;
	}

	public  float getCPUUtilization(String dcDNS) {
		String CPUUtilization = "";
		try{
			URL url = new URL(dcDNS + ":8080/info/cpu");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			
			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			int responseCode = con.getResponseCode();
			while(responseCode != 200) {
				Thread.sleep(2000);
				con = (HttpURLConnection)url.openConnection();
				responseCode = con.getResponseCode();
			}
		
			//System.out.println("\nSending 'GET' request to URL : " + url);
			//System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			//print result
			 Pattern pattern = Pattern.compile("[0-9]*\\.?[0-9]+");
		         Matcher matcher = pattern.matcher(response.toString());
		     while(matcher.find()){
		    	 CPUUtilization = matcher.group(0);
		     }

		} catch (IOException e) {
			return 1000;
		} catch (InterruptedException e) {
			return 1000;
		}
		
		if(!CPUUtilization.equals("")) {
			return Float.parseFloat(CPUUtilization);				
		}else{
			return 1000;
		}
            	
	}
	
	private int findMin(float[] CPUUtilizations) {
		float ret = 1000000;
		int index = -1;
		for(int i=0; i<CPUUtilizations.length; i++) {
			if(CPUUtilizations[i] < ret) {
				ret = CPUUtilizations[i];
				index = i;
			}
		}
		return index;
	}  
}