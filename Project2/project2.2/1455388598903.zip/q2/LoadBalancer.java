import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoadBalancer {
	private static final int THREAD_POOL_SIZE = 4;
	private final ServerSocket socket;
	private final DataCenterInstance[] instances; 
	private float CPUUtilizations [];

	public LoadBalancer(ServerSocket socket, DataCenterInstance[] instances) {
		this.socket = socket;
		this.instances = instances;
		CPUUtilizations = new float[3];
	}

	// Complete this function
         public void start() throws IOException {
         	int size = CPUUtilizations.length;
         	ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
         	int count = 0;
         	//check every 5 requests
         	while(true) {
          		int target =   count%size;
                	if(count % 5 == 0) {  
                 // By default, it will send all requests to the first instance
                       	 CPUUtilizations[0] = getCPUUtilization("cloud-128766vm.eastus.cloudapp.azure.com");
                         CPUUtilizations[1] = getCPUUtilization("cloud-842801vm.eastus.cloudapp.azure.com");
                        CPUUtilizations[2] = getCPUUtilization("cloud-280891vm.eastus.cloudapp.azure.com"); 
                        target = findMin(CPUUtilizations);                       
                 }
                 Runnable requestHandler = new RequestHandler(socket.accept(), instances[target]);
                 executorService.execute(requestHandler);
                 count ++;
               }
        } 
      //find the minmal
	private int findMin(float[] CPUUtilizations) {
		float ret = 1000000;
		int index = -1;
		for(int i=0; i<CPUUtilizations.length; i++) {
			if(CPUUtilizations[i] < ret) {
				ret = CPUUtilizations[i];
				index = i;
			}
		}
		return index;
	}
   
     //get the cpu utilization
	public  float getCPUUtilization(String dcDNS) {
		String CPUUtilization = "";
		try{
			URL url = new URL("http://" + dcDNS + ":8080/info/cpu");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			
			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			int responseCode = con.getResponseCode();
			while(responseCode != 200) {
				Thread.sleep(2000);
				con = (HttpURLConnection)url.openConnection();
				responseCode = con.getResponseCode();
			}
		
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			//print result
			 Pattern pattern = Pattern.compile("[0-9]*\\.?[0-9]+");
		         Matcher matcher = pattern.matcher(response.toString());
		     
		  
		     while(matcher.find()){
		    	 CPUUtilization = matcher.group(0);
		     }

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(!CPUUtilization.equals("")) {
			return Float.parseFloat(CPUUtilization);				
		}else{
			return 100;
		}
           
                    
	
	}

}
