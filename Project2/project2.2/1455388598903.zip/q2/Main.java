import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.ServerSocket;
import java.net.URL;

public class Main {
	private static final int PORT = 80;
	private static DataCenterInstance[] instances;
	private static ServerSocket serverSocket;

	//Update this list with the DNS of your data center instances
	//Remember to put your azure dns here. Don't put IP ADDRESS.
	static {
		instances = new DataCenterInstance[3];
//		String dcDNS0 = VMUtil.createDC();
//		String dcDNS1 = VMUtil.createDC();
//		String dcDNS2 = VMUtil.createDC();
		instances[0] = new DataCenterInstance("First", "http://cloud-890236vm.eastus.cloudapp.azure.com");
		instances[1] = new DataCenterInstance("Second", "http://cloud-236264vm.eastus.cloudapp.azure.com");
		instances[2] = new DataCenterInstance("Third", "http://cloud-67349vm.eastus.cloudapp.azure.com");
	}

	public static void main(String[] args) throws IOException {
//		try {
//			Thread.sleep(20000);
//		} catch (InterruptedException e2) {
//			e2.printStackTrace();
//		}
//		boolean succ = false;
//		while(!succ){
//			succ = true;
//			try {
//				Thread.sleep(100000);
//			} catch (InterruptedException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//			try {
//				checkStart(instances);
//			} catch (Exception e) {
//				succ = false;
//			}
//		}
//		System.out.println("get started..........");
		initServerSocket();
		LoadBalancer loadBalancer = new LoadBalancer(serverSocket, instances);
		loadBalancer.start();
	}
//
//	private static boolean checkStart(DataCenterInstance[] instances) {
//		for(int i = 0; i<instances.length; i++) {
//			if(!checkOne(instances[i])) {
//				return false;
//			}
//			
//		}
//
//		return true;
//	}
//	
//	
//	private static boolean checkOne(DataCenterInstance dataCenterInstance) {
//		try {
//			URL url = new URL("http://" + dataCenterInstance.getUrl());
//System.out.println("this cpu url is  : " + url );
//			HttpURLConnection connection = (HttpURLConnection)url.openConnection();
//			connection.setRequestMethod("GET");
//			int responseCode = connection.getResponseCode();
//			System.err.println(responseCode);
//			if(responseCode == 200) {
//				return true;
//			}
//		} catch (IOException e) {
//			return false;
//		}
//		   return false;
//	}

	/**
	 * Initialize the socket on which the Load Balancer will receive requests from the Load Generator
	 */
	private static void initServerSocket() {
		try {
			serverSocket = new ServerSocket(PORT);
		} catch (IOException e) {
			System.err.println("ERROR: Could not listen on port: " + PORT);
			e.printStackTrace();
			System.exit(-1);
		}
	}
}
