import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;






import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.autoscaling.AmazonAutoScalingClient;
import com.amazonaws.services.autoscaling.model.CreateAutoScalingGroupRequest;
import com.amazonaws.services.autoscaling.model.CreateLaunchConfigurationRequest;
import com.amazonaws.services.autoscaling.model.DeleteAutoScalingGroupRequest;
import com.amazonaws.services.autoscaling.model.DeleteLaunchConfigurationRequest;
import com.amazonaws.services.autoscaling.model.InstanceMonitoring;
import com.amazonaws.services.autoscaling.model.PutScalingPolicyRequest;
import com.amazonaws.services.autoscaling.model.UpdateAutoScalingGroupRequest;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchClient;
import com.amazonaws.services.cloudwatch.model.ComparisonOperator;
import com.amazonaws.services.cloudwatch.model.Dimension;
import com.amazonaws.services.cloudwatch.model.PutMetricAlarmRequest;
import com.amazonaws.services.cloudwatch.model.StandardUnit;
import com.amazonaws.services.cloudwatch.model.Statistic;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.AuthorizeSecurityGroupIngressRequest;
import com.amazonaws.services.ec2.model.CreateSecurityGroupRequest;
import com.amazonaws.services.ec2.model.CreateSecurityGroupResult;
import com.amazonaws.services.ec2.model.CreateTagsRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.IpPermission;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.elasticloadbalancing.AmazonElasticLoadBalancingClient;
import com.amazonaws.services.elasticloadbalancing.model.ConfigureHealthCheckRequest;
import com.amazonaws.services.elasticloadbalancing.model.ConnectionDraining;
import com.amazonaws.services.elasticloadbalancing.model.CreateLoadBalancerRequest;
import com.amazonaws.services.elasticloadbalancing.model.DeleteLoadBalancerRequest;
import com.amazonaws.services.elasticloadbalancing.model.HealthCheck;
import com.amazonaws.services.elasticloadbalancing.model.Listener;
import com.amazonaws.services.elasticloadbalancing.model.LoadBalancerAttributes;
import com.amazonaws.services.elasticloadbalancing.model.ModifyLoadBalancerAttributesRequest;

public class AWSAuto {
	// the thing I want to create
	private static Properties properties = null;
	private static BasicAWSCredentials basicAWSCredentials = null;
	private static AmazonAutoScalingClient amazonAutoScalingClient = null;
	private static AmazonEC2Client amazonEC2Client = null;
	private static AmazonCloudWatchClient amazonCloudWatchClient = null;
	private static AmazonElasticLoadBalancingClient amazonElasticLoadBalancingClient = null;
	private static HealthCheck healthCheck = null;
	private static CreateLaunchConfigurationRequest createLaunchConfigurationRequest = null;
	private static CreateAutoScalingGroupRequest createAutoScalingGroupRequest = null;
	
	
	// the important url
	private static String lgDNS = null;
	private static String elbDNS = null;
	
	
	//tag info
	private static final String tagKey = "Project";
	private static final String tagValue = "2.1";

	//authentication
	private static final String propertyName = "/AwsCredentials.properties";
	private static final String propertyKey = "aws_access_key_id";
	private static final String propertyValue ="aws_secret_access_key";
	
	//security group info
	private static final String securityGroupName1 = "securityGroup1";
	private static final String securityGroupName2 = "securityGroup2";
	private static final String securityGroupDesc1 = "securityGroupDesc1";
	private static final String securityGroupDesc2 = "securityGroupDesc2";

	private static final String securityGroupIpRange = "0.0.0.0/0";
	private static final String securityGroupProtocal = "-1";
	
	//load generator info 
	private static final String lgImageId = "ami-8ac4e9e0";
	private static final String instanceType = "m3.large";
    private static final String pem = "15319demo"; 
    
    //load balance info
    private static final String loadBalanceName = "ELB";
    
    //data center to be added to load balancer
    private static final String dcImageId = "ami-349fbb5e";
    
   
    //launch Configuration info 
    private static final String launchConfigurationName = "launchConfiguration";
   
    //scaling group info
    private static final String autoScalingGroupName = "autoScalingGroupName";
    
    //policy info 
	private static String scaleUp = "scaleUp";
    private static String scaleDown = "scaleDown";
   
    //cloud watch info
    private static final String availablityzone = "us-east-1a";
    private static final String alarmName1 = "high"; 
    private static final String alarmName2 = "low";
    private static final String metricName = "utilization";
    private static final String nameSpace = "AWS/EC2";
    
    //fill the info
    private static final String id = "qiangwan";
    private static final String password = "gaOcmbHE1SqJiSn8WG7GyDJtAX77n6to";
    
    //testinfo
    private static String testNumber = ""; 
    
   
    
    //a lot of create functions 
    
   /**
     * authentication
     * @return
     * @throws IOException
     */
    public static void getCreadentials() throws IOException {
    	properties = new Properties();
		properties.load(RunInstance.class.getResourceAsStream(propertyName));
	    basicAWSCredentials = new BasicAWSCredentials(properties.getProperty(propertyKey), properties.getProperty(propertyValue));
    }
    
    
    /**
     * create the ec2 to ask request
     */
    public static void createAmazonEC2Client() {
    	amazonEC2Client = new AmazonEC2Client(basicAWSCredentials);
    }
    
    
	/**http://docs.aws.amazon.com/AWSSdkDocsJava/latest/DeveloperGuide/create-security-group.html
	 * createSecurtityGroup
	 * @param amazonEC2Client
	 * @return
	 */
    public static String createSecurityGroup(String securityGroupName, String securityGroupDesc) {
		CreateSecurityGroupRequest csgr = new CreateSecurityGroupRequest();
		csgr.withGroupName(securityGroupName).withDescription(securityGroupDesc);
		CreateSecurityGroupResult createSecurityGroupResult = amazonEC2Client.createSecurityGroup(csgr);
		IpPermission ipPermission = new IpPermission();
		ipPermission.withIpRanges(securityGroupIpRange).withIpProtocol(securityGroupProtocal);
		AuthorizeSecurityGroupIngressRequest authorizeSecurityGroupIngressRequest = new AuthorizeSecurityGroupIngressRequest();
		authorizeSecurityGroupIngressRequest.withGroupName(securityGroupName).withIpPermissions(ipPermission);
		amazonEC2Client.authorizeSecurityGroupIngress(authorizeSecurityGroupIngressRequest);
		String groupId = createSecurityGroupResult.getGroupId();
		return groupId;
	}
    
    
    /**
     * create load generator and the dns of load generator
     * @param bawsc
     * @return
     */
    public static void createLG(String groupName) {
		RunInstancesRequest runInstancesRequest = new RunInstancesRequest();
		runInstancesRequest.withImageId(lgImageId)
		.withInstanceType("m3.medium")
		.withMinCount(1)
		.withMaxCount(1)
		.withKeyName(pem)
		.withSecurityGroups(groupName);
		
		RunInstancesResult runInstancesResult = amazonEC2Client.runInstances(runInstancesRequest);   
		Instance instance=runInstancesResult.getReservation().getInstances().get(0);
		CreateTagsRequest createTagsRequest = new CreateTagsRequest();	
		createTagsRequest.withResources(instance.getInstanceId()).withTags(new Tag(tagKey, tagValue));
		amazonEC2Client.createTags(createTagsRequest);
		String instanceId =  instance.getInstanceId();
		
		lgDNS = getInstancePublicDnsName(instanceId);
System.out.println(lgDNS);		
		while(lgDNS.equals("")) {
			lgDNS = getInstancePublicDnsName(instanceId);
		}
	}
    
	/**
	 * get the instance ID
	 * @param instanceId
	 * @return
	 */
	private static String getInstancePublicDnsName(String instanceId) {
	    DescribeInstancesResult describeInstancesRequest = amazonEC2Client.describeInstances();
	    List<Reservation> reservations = describeInstancesRequest.getReservations();
	    for (Reservation reservation : reservations) {
	      for (Instance instance : reservation.getInstances()) {
	        if (instance.getInstanceId().equals(instanceId))
	          return instance.getPublicDnsName();
	      }
	    }
	    return null;
	}
	
	/**things need to configure when creating ELB: tag, zone, group, listener, and the port 
	 * the first port is when the elb listen, the second is when the instance(data center listen)
	 * create the elb and get the dns of it 
	 * @param groupID
	 */
	public static void  createELB(String groupID){
		amazonElasticLoadBalancingClient = new AmazonElasticLoadBalancingClient(basicAWSCredentials);
		CreateLoadBalancerRequest clbr = new CreateLoadBalancerRequest().withTags(new com.amazonaws.services.elasticloadbalancing.model.Tag().withKey(tagKey).withValue(tagValue))
				.withAvailabilityZones(availablityzone).withSecurityGroups(groupID).withListeners(new Listener("HTTP",80,80))
                .withLoadBalancerName(loadBalanceName);
		elbDNS = amazonElasticLoadBalancingClient.createLoadBalancer(clbr).getDNSName();	
		
		//disenable drain
		LoadBalancerAttributes loadBalancerAttributes = new LoadBalancerAttributes();
		loadBalancerAttributes.withConnectionDraining(new ConnectionDraining().withEnabled(false));
		
		ModifyLoadBalancerAttributesRequest modifyLBAttrRequest = new ModifyLoadBalancerAttributesRequest();
		modifyLBAttrRequest.withLoadBalancerAttributes(loadBalancerAttributes)
		.withLoadBalancerName(loadBalanceName);
		amazonElasticLoadBalancingClient.modifyLoadBalancerAttributes(modifyLBAttrRequest);
		
	}
	
	/**
	 * create the healthCheck
	 */
	public static void createHealthCheck() {
		healthCheck = new HealthCheck().withTimeout(5)
                .withHealthyThreshold(10)
                .withUnhealthyThreshold(2)
                .withInterval(30)
                .withTarget("HTTP:80/heartbeat?lg="+lgDNS);
	   ConfigureHealthCheckRequest configureHealthCheckRequest = new ConfigureHealthCheckRequest()
	   	.withHealthCheck(healthCheck)
	   	.withLoadBalancerName(loadBalanceName);
	   amazonElasticLoadBalancingClient.configureHealthCheck(configureHealthCheckRequest);
	}
	
	/**
	 * create launch configuration
	 * @param groupId
	 */
	public static void createLaunchConfiguration(String groupId ) {
		 createLaunchConfigurationRequest = new CreateLaunchConfigurationRequest()
		.withImageId(dcImageId)
		.withInstanceType(instanceType)
		.withSecurityGroups(groupId)
		.withLaunchConfigurationName(launchConfigurationName)
		.withInstanceMonitoring(new InstanceMonitoring().withEnabled(true))
		.withKeyName(pem);	
	} 
	
	/**
	 * create the auto scaling group
	 */
	public static  void createAutoScalingGroup() {
		createAutoScalingGroupRequest = new CreateAutoScalingGroupRequest()
		.withTags(new com.amazonaws.services.autoscaling.model.Tag().withKey(tagKey).withValue(tagValue))
		.withAvailabilityZones(availablityzone)
		.withAutoScalingGroupName(autoScalingGroupName)
		.withHealthCheckType(loadBalanceName)
		.withLaunchConfigurationName(launchConfigurationName)
		.withLoadBalancerNames(loadBalanceName)
		.withDefaultCooldown(60)
		.withDesiredCapacity(2)
		.withMinSize(2)
		.withMaxSize(2)
		.withHealthCheckGracePeriod(180);
	}
	
	public static void createAutoscalingClient() {
		amazonAutoScalingClient = new AmazonAutoScalingClient(basicAWSCredentials);
	}
	
	
	public static void addConfigurationAndGroupToClient() {
		amazonAutoScalingClient.createLaunchConfiguration(createLaunchConfigurationRequest);
		amazonAutoScalingClient.createAutoScalingGroup(createAutoScalingGroupRequest);
	}
	
	
	/**
	 * strategy
	 */
	public static void createPolicy() {
		// need more
		PutScalingPolicyRequest scaleOutOne = new PutScalingPolicyRequest();
		scaleOutOne.withAdjustmentType("ChangeInCapacity")
		.withPolicyName(scaleUp)
		.withScalingAdjustment(0)
		.withAutoScalingGroupName(autoScalingGroupName)
		.withCooldown(60);
		
		//need less
		PutScalingPolicyRequest scaleInOne = new PutScalingPolicyRequest();
		scaleInOne.withAdjustmentType("ChangeInCapacity")
		.withPolicyName(scaleDown)
		.withScalingAdjustment(0)
		.withAutoScalingGroupName(autoScalingGroupName)
		.withCooldown(60);

		// add
		String up = amazonAutoScalingClient.putScalingPolicy(scaleOutOne).getPolicyARN();
		//delete
        String down = amazonAutoScalingClient.putScalingPolicy(scaleInOne).getPolicyARN();

        Dimension dm = new Dimension()
                .withName(autoScalingGroupName)
                .withValue(autoScalingGroupName);

        
        //if need more 
        PutMetricAlarmRequest add = new PutMetricAlarmRequest()
        		.withAlarmActions(up)
                .withAlarmName(alarmName1)
                .withMetricName(metricName)
                .withDimensions(dm)
                .withNamespace(nameSpace)
                .withComparisonOperator(ComparisonOperator.LessThanOrEqualToThreshold)
                .withStatistic(Statistic.Average)
                .withUnit(StandardUnit.Percent)
                .withThreshold(70d)
                .withPeriod(60)
                .withEvaluationPeriods(1);
     
        //if need less
        PutMetricAlarmRequest delete = new PutMetricAlarmRequest()
        		.withAlarmActions(down)
                .withAlarmName(alarmName2)
                .withMetricName(metricName)
                .withDimensions(dm)
                .withNamespace(nameSpace)
                .withComparisonOperator(ComparisonOperator.GreaterThanOrEqualToThreshold)
                .withStatistic(Statistic.Average)
                .withUnit(StandardUnit.Percent)
                .withThreshold(30d)
                .withPeriod(60)
                .withEvaluationPeriods(1);
        
        amazonCloudWatchClient = new AmazonCloudWatchClient(basicAWSCredentials);
        amazonCloudWatchClient.putMetricAlarm(add);
        amazonCloudWatchClient.putMetricAlarm(delete);
	
	}
	
	/**
	 * delete resourses except lg	
	 * @throws InterruptedException
	 */
	public static void terminate() throws InterruptedException {
		 UpdateAutoScalingGroupRequest updateAutoScalingGroupRequest = new UpdateAutoScalingGroupRequest()
         .withDesiredCapacity(0)
         .withMinSize(0)
         .withMaxSize(0)
         .withAvailabilityZones(availablityzone)
         .withAutoScalingGroupName(autoScalingGroupName);
		 
		 amazonAutoScalingClient.updateAutoScalingGroup(updateAutoScalingGroupRequest);
		 
		 Thread.sleep(120000);
		 
		 DeleteAutoScalingGroupRequest deleteAutoScalingGroupRequest = new DeleteAutoScalingGroupRequest()
		 .withAutoScalingGroupName(autoScalingGroupName);
		 amazonAutoScalingClient.deleteAutoScalingGroup(deleteAutoScalingGroupRequest);
		 
		DeleteLaunchConfigurationRequest deleteLaunchConfigurationRequest = new DeleteLaunchConfigurationRequest().
				withLaunchConfigurationName(launchConfigurationName);
		amazonAutoScalingClient.deleteLaunchConfiguration(deleteLaunchConfigurationRequest);
		
		DeleteLoadBalancerRequest deleteLoadBalancerRequest = new DeleteLoadBalancerRequest().withLoadBalancerName(loadBalanceName);
		amazonElasticLoadBalancingClient.deleteLoadBalancer(deleteLoadBalancerRequest);
		

		
	}
	
	public static void fillIdPassword() throws IOException, InterruptedException  {
			URL url = new URL("http://" + lgDNS + "/password?passwd=" + password + "&andrewId=" + id);
System.out.println("pw and id url : " + url );
			HttpURLConnection connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod("GET");
			int responseCode = connection.getResponseCode();
			System.err.println(responseCode);
			while(responseCode != 200) {
				Thread.sleep(2000);
				connection = (HttpURLConnection)url.openConnection();
				responseCode = connection.getResponseCode();
System.out.println(responseCode);
			}
}
	public static void warmUp() throws IOException, InterruptedException {	
			URL url = new URL("http://"+lgDNS+"/warmup?dns="+elbDNS);
System.out.println("url of lg and dc :  " + url);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();

			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			int responseCode = con.getResponseCode();
			while(responseCode != 200) {
				Thread.sleep(2000);
				con = (HttpURLConnection)url.openConnection();
				responseCode = con.getResponseCode();
System.out.println(responseCode);
			}
	}
	
	public static void startTest() {
		try {
			URL url = new URL("http://" + lgDNS + "/junior?dns=" + elbDNS);
System.out.println("url of lg and dc :  " + url);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			int responseCode = con.getResponseCode();
			while(responseCode != 200) {
				Thread.sleep(2000);
				con = (HttpURLConnection)url.openConnection();
				responseCode = con.getResponseCode();
System.out.println(responseCode);
			}
		
System.out.println("\nSending 'GET' request to URL : " + url);
System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			//print result
			 Pattern pattern = Pattern.compile("test.([+\\d]+).log");
		     Matcher matcher = pattern.matcher(response.toString());
		     
		     while(matcher.find()){
		    	 testNumber = matcher.group(0);
		     }
		     
		     testNumber = testNumber.split("\\.")[1];


		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	    
	}


	
	
	public static void main(String [] args) throws IOException, InterruptedException {
		AWSAuto.getCreadentials();
System.out.println("finish creating credential ...");

		AWSAuto.createAmazonEC2Client();
System.out.println("finish creating the ec2client...");

		String groupId1 = createSecurityGroup(securityGroupName1, securityGroupDesc1);
		String groupId2 = createSecurityGroup(securityGroupName2, securityGroupDesc2);
System.out.println("finish adding security group... :" + groupId1 + " and " + groupId2);

		AWSAuto.createLG(securityGroupName1);
		AWSAuto.createELB(groupId2);
System.out.println("finish creating elb ...: " + elbDNS);

		AWSAuto.createHealthCheck();
System.out.println("finish creating health check ... " + healthCheck.getTarget());

		AWSAuto.createLaunchConfiguration(groupId2);
System.out.println("finish creating launch configuration.. ");

		AWSAuto.createAutoScalingGroup();
System.out.println("finish creating autoscaling group ... ");
			
		AWSAuto.createAutoscalingClient();
System.out.println("finish creating auto scaling client.. ");

		AWSAuto.addConfigurationAndGroupToClient();
System.out.println("finish add ...");
		AWSAuto.createPolicy();
System.out.println("finish creating policy");		
		
		Thread.sleep(200000);
		
		boolean succ = false;
		while(!succ){
			succ = true;
			Thread.sleep(200000);
			try {
				fillIdPassword();
			} catch (Exception e) {
				succ = false;
			}
		}
        
        
     
        Thread.sleep(50000);
        
        for(int i=0; i<2; i++) {
        	warmUp();
        	Thread.sleep(1000000);
        }
        
        
        startTest();
        
        Thread.sleep(2880000);
		terminate();
		        
	}
}
