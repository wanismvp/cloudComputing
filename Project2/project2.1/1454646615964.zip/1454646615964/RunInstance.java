import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.CreateTagsRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;


public class RunInstance {
	private static String lgImageId = "ami-8ac4e9e0";
	private static String dcImageId = "ami-349fbb5e";
	private static String instanceType = "m3.medium";
    private static String pem = "15319demo"; 
    private static String securityGroup = "webserver";
	
	
	/**
	 * this function is used to add data center to load generator
	 * @param lgDNS
	 * @param dcDNS
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String addDC(String lgDNS, String dcDNS) throws IOException, InterruptedException {
		String testNumber = "";
		URL url = new URL("http://" + lgDNS + "/test/horizontal/add?dns=" + dcDNS);
System.out.println("add dcDNS url :" + url);
		HttpURLConnection connection = (HttpURLConnection)url.openConnection();
		connection.setRequestMethod("GET");
		int responseCode = connection.getResponseCode();
		System.err.println(responseCode);
		while(responseCode != 200) {
			Thread.sleep(2000);
			connection = (HttpURLConnection)url.openConnection();
			responseCode = connection.getResponseCode();
		}
		return testNumber;
	}
	
	
	/**
	 * fill the password and id
	 * @param lgDNS
	 * @param id
	 * @param password
	 * @return
	 */
	public static boolean fillIdPassword(String lgDNS, String id, String password)  {
		try {
			URL url = new URL("http://" + lgDNS + "/password?passwd=" + password + "&andrewid=" + id);
System.out.println("pw and id url : " + url );
			HttpURLConnection connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod("GET");
			int responseCode = connection.getResponseCode();
			System.err.println(responseCode);
			while(responseCode != 200) {
				Thread.sleep(2000);
				connection = (HttpURLConnection)url.openConnection();
				responseCode = connection.getResponseCode();
System.out.println(responseCode);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	    
	return true;
}
	
	
	/**
	 * start the test
	 * @param lgDNS
	 * @param dcDNS
	 * @return
	 */
	public static String startTest(String lgDNS, String dcDNS) {
		String testNumber = "";
		try {
			URL url = new URL("http://" + lgDNS + "/test/horizontal?dns=" + dcDNS);
System.out.println("url of lg and dc :  " + url);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();

			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			int responseCode = con.getResponseCode();
			while(responseCode != 200) {
				Thread.sleep(2000);
				con = (HttpURLConnection)url.openConnection();
				responseCode = con.getResponseCode();
System.out.println(responseCode);
			}
		
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			//print result
			 Pattern pattern = Pattern.compile("test.([+\\d]+).log");
		     Matcher matcher = pattern.matcher(response.toString());
		     
		    
		     while(matcher.find()){
		    	 testNumber = matcher.group(0);
		     }
		     
		     testNumber = testNumber.split("\\.")[1];


		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	    
		return testNumber;
	}
		
	/**
	 * get the rps from log 
	 * @param lgDNS
	 * @param testNumber
	 * @param num
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static int monitor(String lgDNS, String testNumber, int num) throws IOException, InterruptedException {    
        URL url = new URL("http://" + lgDNS + "/log?name=test."+ testNumber + ".log");
System.out.println("the log url: " + url);
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();
        connection.setDoOutput(true);      
        String line = null;  
        InputStream inputStream  = connection.getInputStream();  
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(  
                inputStream));  
        
        int responseCode = connection.getResponseCode();
		while(responseCode != 200) {
			Thread.sleep(2000);
			connection = (HttpURLConnection)url.openConnection();
			responseCode = connection.getResponseCode();;
		}
        
        StringBuffer response = new StringBuffer();
    	
		while ((line = bufferedReader.readLine()) != null) {
			if(line.startsWith("ec2-")) {
System.out.println(line);
				response.append(line.trim() + " ");
			}
		}

		String [] strs = response.toString().trim().split("\\s+");	
		for(String s : strs) {
System.out.println(s);			
		}
		int len = strs.length;
System.out.println(len);
		int start = 0;
		int rps = 0;
		while(start < num) {
System.out.println(strs[len -1- start]);
			String temp = (strs[len -1- start].split("=")[1]);
System.out.println(temp);
			int t =  (int) Float.parseFloat(temp);
System.out.println(t);
			rps = rps + t;
System.out.println(rps);
			start ++;
		} 
       
       return rps;
    }
	
	/**
	 * create the lg
	 * @param bawsc
	 * @return
	 */
	public static String createLG(BasicAWSCredentials bawsc) {
		AmazonEC2Client ec2 = new AmazonEC2Client(bawsc);
		//Create Instance Request
		RunInstancesRequest runInstancesRequest = new RunInstancesRequest();
		//Configure Instance Request
		runInstancesRequest.withImageId(lgImageId)
		.withInstanceType(instanceType)
		.withMinCount(1)
		.withMaxCount(1)
		.withKeyName(pem)
		.withSecurityGroups(securityGroup);
		//Launch Instance
		RunInstancesResult runInstancesResult = ec2.runInstances(runInstancesRequest);   
		//Return the Object Reference of the Instance just Launched
		Instance instance=runInstancesResult.getReservation().getInstances().get(0);
		CreateTagsRequest createTagsRequest = new CreateTagsRequest();	
		createTagsRequest.withResources(instance.getInstanceId()).withTags(new Tag("Project", "2.1"));
		ec2.createTags(createTagsRequest); 
		String instanceId =  instance.getInstanceId();
		
		String lgDNS = getInstancePublicDnsName(instanceId, ec2);
System.out.println(lgDNS);		
		while(lgDNS.equals("")) {
			lgDNS = getInstancePublicDnsName(instanceId, ec2);
		}
		return lgDNS;
	}
	
	/**
	 * create data center
	 * @param bawsc
	 * @return
	 * @throws Exception
	 */
	public static String createDC(BasicAWSCredentials bawsc) throws Exception {
		AmazonEC2Client ec2 = new AmazonEC2Client(bawsc);
		//Create Instance Request
		RunInstancesRequest runInstancesRequest = new RunInstancesRequest();
		//Configure Instance Request
		runInstancesRequest.withImageId(dcImageId)
		.withInstanceType(instanceType)
		.withMinCount(1)
		.withMaxCount(1)
		.withKeyName(pem)
		.withSecurityGroups(securityGroup);
		//Launch Instance
		RunInstancesResult runInstancesResult = ec2.runInstances(runInstancesRequest);   
		//Return the Object Reference of the Instance just Launched
		Instance instance=runInstancesResult.getReservation().getInstances().get(0);
		CreateTagsRequest createTagsRequest = new CreateTagsRequest();	
		createTagsRequest.withResources(instance.getInstanceId()).withTags(new Tag("Project", "2.1"));
		ec2.createTags(createTagsRequest); 
		String instanceId =  instance.getInstanceId();
		
		String dcDNS = getInstancePublicDnsName(instanceId, ec2);
System.out.println(dcDNS);
		while(dcDNS.equals("")) {
			dcDNS = getInstancePublicDnsName(instanceId, ec2);
		}
		return dcDNS;
	 }
	/**
	 * get the dns
	 * @param instanceId
	 * @param ec2
	 * @return
	 */
	static String getInstancePublicDnsName(String instanceId, AmazonEC2Client ec2) {
	    DescribeInstancesResult describeInstancesRequest = ec2.describeInstances();
	    List<Reservation> reservations = describeInstancesRequest.getReservations();
	    Set<Instance> allInstances = new HashSet<Instance>();
	    for (Reservation reservation : reservations) {
	      for (Instance instance : reservation.getInstances()) {
	        if (instance.getInstanceId().equals(instanceId))
	          return instance.getPublicDnsName();
	      }
	    }
	    return null;
	}
	
	
	
	
	public static void main(String []args) throws Exception {
		//Load the Properties File with AWS Credentials
		Properties properties = new Properties();
		properties.load(RunInstance.class.getResourceAsStream("/AwsCredentials.properties"));
		BasicAWSCredentials bawsc = new BasicAWSCredentials(properties.getProperty("accessKey"), properties.getProperty("secretKey"));
		
		
		String lgDNS = createLG(bawsc);
		String dcDNS = createDC(bawsc);
		//String lgDNS = "ec2-54-208-22-205.compute-1.amazonaws.com";
		//String dcDNS = "ec2-54-152-95-4.compute-1.amazonaws.com";
		Thread.sleep(50000);

    	
		System.out.println("Beging submmit pw and id");
		    	boolean success = fillIdPassword(lgDNS,"qiangwan","gaOcmbHE1SqJiSn8WG7GyDJtAX77n6to");
		System.out.println("finish submit pw and id");

		    	
    	int numOfdc = 1;
    	if(success == true) {
System.out.println("begin test and get testNumber");  
    		String testNumber = startTest(lgDNS, dcDNS);
    		Thread.sleep(100000);
System.out.println("finish test and get testNumber");
        	while(true) {
        		int rps = 0;
System.out.println("beging monitor ..");
        		rps = monitor(lgDNS, testNumber, numOfdc);
System.out.println("finish monitor ..");
			    if (rps >= 4000) {
        			break;
        		}else {
        			dcDNS = createDC(bawsc);
        			numOfdc ++;
        			Thread.sleep(3 *60*1000);
        			addDC(lgDNS, dcDNS);
        			//Thread.sleep(2 *60*1000);
        		}
        	}	
    	}
//Create an Amazon EC2 Client
	
		
	}
	
	 
	
	
	
}
