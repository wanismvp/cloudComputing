import org.vertx.java.core.Handler;

import org.vertx.java.core.http.HttpServerRequest;
import org.vertx.java.platform.Verticle;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class MSB extends Verticle {
	class LRUCache<K ,V> extends LinkedHashMap<K, V> {
		private LinkedHashMap<K, V>cache = null;
		private int cacheSize = 0;
		
		public LRUCache(int cacheSize) {
			this.cacheSize = cacheSize;
			int hashTableCapacity = (int)Math.ceil(cacheSize/0.75f) + 1;
			cache = new LinkedHashMap<K, V>(hashTableCapacity, 0.75f, true) {
				private final long serialVersionUID = 1;
				
				protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
					return size() > LRUCache.this.cacheSize;
				}
				
			};
		}
		
		public boolean containsKey(Object key) {
			// TODO Auto-generated method stub
			return cache.containsKey(key);
		}
		public V put(K key, V value) {
			return cache.put(key, value);
		}
		
		public V get(Object key) {
			return cache.get(key);
		}
	}

	private final int MAX_CACHE= 999;	
	private final int fetchSize = 25;
	private String[] databaseInstances = new String[2];		
	private LRUCache<String, String>lruCache =  null;
	private int countRequest = 0;		
	/* 
	 * init -initializes the variables which store the 
	 *	     DNS of your database instances
	 */
	private void init() {
		/* Add the DNS of your database instances here */
		databaseInstances[0] = "ec2-54-172-129-162.compute-1.amazonaws.com";
		databaseInstances[1] = "ec2-52-91-85-124.compute-1.amazonaws.com";
		lruCache = new LRUCache<String, String>(MAX_CACHE);
	}
	
	/*
	 * checkBackend - verifies that the DCI are running before starting this server
	 */	
	private boolean checkBackend() {
    	try{
    		if(sendRequest(generateURL(0,"1")) == null ||
            	sendRequest(generateURL(1,"1")) == null)
        		return true;
    	} catch (Exception ex) {
    		System.out.println("Exception is " + ex);
    	}

    	return false;
	}

	/*
	 * sendRequest
	 * Input: URL
	 * Action: Send a HTTP GET request for that URL and get the response
	 * Returns: The response
	 */
	private String sendRequest(String requestUrl) throws Exception {
		 
		URL url = new URL(requestUrl);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();

		connection.setRequestMethod("GET");
		connection.setRequestProperty("User-Agent", "Mozilla/5.0");
 
		BufferedReader in = new BufferedReader(
					new InputStreamReader(connection.getInputStream(), "UTF-8"));
		
		String responseCode = Integer.toString(connection.getResponseCode());
		if(responseCode.startsWith("2")){
			String inputLine;
			StringBuffer response = new StringBuffer();
 
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			return response.toString();
    	} else {
    		System.out.println("Unable to connect to "+requestUrl+
    		". Please check whether the instance is up and also the security group settings"); 
    		return null;
    	}   
	}
	/*
	 * generateURL
	 * Input: Instance ID of the Data Center id
	 * Returns: URL which can be used to retrieve the user's details
	 * 			from the data center instance
	 * Additional info: the user's details are cached on backend instance
	 */
	private String generateURL(Integer instanceID, String key) {
		return "http://" + databaseInstances[instanceID] + "/target?targetID=" + key;
	}
	
	/*
	 * generateRangeURL
	 * Input: 	Instance ID of the Data Center
	 * 		  	startRange - starting range (id)
	 *			endRange - ending range (id)
	 * Returns: URL which can be used to retrieve the details of all
	 * 			user in the range from the data center instance
	 * Additional info: the details of the last 1000 user are cached
	 * 					in the database instance
	 * 				
	 */
	private String generateRangeURL(Integer instanceID, Integer startRange, Integer endRange) {
		return "http://" + databaseInstances[instanceID] + "/range?start_range="
				+ Integer.toString(startRange) + "&end_range=" + Integer.toString(endRange);
	}

	/* 
	 * retrieveDetails - you have to modify this function to achieve a higher RPS value
	 * Input: the targetID
	 * Returns: The result from querying the database instance
	 */
	private String retrieveDetails(String targetID) {
System.out.println("one request: " + targetID);
	int id = Integer.parseInt(targetID);
	int first = id - fetchSize;
	int last = id + fetchSize;
	System.out.println(last-first+1);
		try{
			if(lruCache.containsKey(targetID)) {
System.out.println("hit");
				return lruCache.get(targetID);
			}else {
System.out.println("miss");
				String data = sendRequest(generateRangeURL(countRequest%2, first, last));
				countRequest++;
				String [] datas = data.split(";");
				for(int i=0; i<datas.length; i++) {
					lruCache.put(String.valueOf(first), datas[i]);
					first ++; 
				}
				return lruCache.get(targetID);
			}	
		} catch (Exception ex){
			System.out.println(ex);
			return null;
		}
	}
	
	/* 
	 * processRequest - calls the retrieveDetails function with the id
	 */
	private void processRequest(String id, HttpServerRequest req) {
		String result = retrieveDetails(id);
		if(result != null)
			req.response().end(result);	
		else
			req.response().end("No resopnse received");
	}
	
	/*
	 * start - starts the server
	 */
  	public void start() {
  		init();
		if(!checkBackend()){
  			vertx.createHttpServer().requestHandler(new Handler<HttpServerRequest>() {
				public void handle(HttpServerRequest req) {
				    String query_type = req.path();		
				    req.response().headers().set("Content-Type", "text/plain");
				    if(query_type.equals("/target")) {
					    String key = req.params().get("targetId");
					    processRequest(key,req);
				    }
			    }               
			}).listen(80);
		} else {
			System.out.println("Please make sure that both your DCI are up and running");
		}
	}
}
